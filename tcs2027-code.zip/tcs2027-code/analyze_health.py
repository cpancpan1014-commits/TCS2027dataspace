#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第二阶段：读取扫描结果，做覆盖率与可行性评估，产出报告"""
import csv, json, os, statistics as st
from collections import defaultdict, Counter
from datetime import date, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))

D = HERE + "/health_data"
OUT = HERE
def read_csv(p):
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


summ = json.load(open(f"{D}/scan_summary.json", encoding="utf-8"))
daily = read_csv(f"{D}/daily_agg.csv")
workouts = read_csv(f"{D}/workouts.csv")
rings = read_csv(f"{D}/activity_rings.csv")

hrv = read_csv(f"{D}/HeartRateVariabilitySDNN.csv")
rhr = read_csv(f"{D}/RestingHeartRate.csv")
sleep = read_csv(f"{D}/SleepAnalysis.csv")
wrist = read_csv(f"{D}/AppleSleepingWristTemperature.csv")
vo2 = read_csv(f"{D}/VO2Max.csv")
hrr = read_csv(f"{D}/HeartRateRecoveryOneMinute.csv")
hravg = read_csv(f"{D}/WalkingHeartRateAverage.csv")
resp = read_csv(f"{D}/RespiratoryRate.csv")
bm = read_csv(f"{D}/BodyMass.csv")

# 2026 年过去的天数
first = min([r["date"] for r in daily] + [r["date"] for r in hrv] + [r["date"] for r in workouts] or ["2026-01-01"])
last = max([r["date"] for r in daily] + [r["date"] for r in hrv] + [r["date"] for r in workouts] or ["2026-10-15"])
d0 = date.fromisoformat(first)
d1 = date.fromisoformat(last)
span_days = (d1 - d0).days + 1


def coverage(rows, key="date"):
    ds = {r[key] for r in rows if r.get(key)}
    return len(ds)


def monthly(rows):
    c = Counter(r["date"][:7] for r in rows if r.get("date"))
    return dict(sorted(c.items()))


def vals(rows):
    return [v for v in (num(r.get("value")) for r in rows) if v is not None]


print("=" * 78)
print(f"数据时间跨度：{first} ~ {last}（{span_days} 天）")
print("=" * 78)

sig = []
sig.append(("HRV (SDNN)", hrv))
sig.append(("静息心率", rhr))
sig.append(("睡眠分析", sleep))
sig.append(("腕温", wrist))
sig.append(("VO2Max", vo2))
sig.append(("运动后1分钟心率恢复", hrr))
sig.append(("步行平均心率", hravg))
sig.append(("呼吸频率", resp))
sig.append(("体重", bm))

print(f"\n{'指标':<22}{'记录数':>8}{'覆盖天数':>10}{'覆盖率':>9}   日期范围")
print("-" * 78)
report = []
for name, rows in sig:
    n = len(rows)
    cd = coverage(rows)
    rng = f"{min((r['date'] for r in rows), default='-')} ~ {max((r['date'] for r in rows), default='-')}"
    rate = f"{cd/span_days*100:.0f}%"
    print(f"{name:<22}{n:>8}{cd:>10}{rate:>9}   {rng}")
    report.append({"指标": name, "记录数": n, "覆盖天数": cd,
                   "覆盖率": f"{cd/span_days*100:.1f}%", "日期范围": rng})

print(f"\n{'每日聚合指标':<22}{'覆盖天数':>10}{'覆盖率':>9}")
print("-" * 78)
for col, label in [("hr_mean", "平均心率(日)"), ("active_energy", "活动能量(日)"),
                   ("steps", "步数(日)"), ("distance", "距离(日)"),
                   ("exercise_min", "锻炼分钟(日)")]:
    n = sum(1 for r in daily if r.get(col))
    print(f"{label:<22}{n:>10}{n/span_days*100:>8.0f}%")
    report.append({"指标": label, "记录数": n, "覆盖天数": n,
                   "覆盖率": f"{n/span_days*100:.1f}%", "日期范围": f"{first} ~ {last}"})

# ---- HRV 分布 ----
hv = vals(hrv)
print(f"\n【HRV 数值分布】n={len(hv)}")
if hv:
    print(f"  均值 {st.mean(hv):.1f} ms  中位数 {st.median(hv):.1f}  标准差 {st.pstdev(hv):.1f}"
          f"  范围 {min(hv):.0f}–{max(hv):.0f}")
    print(f"  个体内变异系数 CV = {st.pstdev(hv)/st.mean(hv)*100:.1f}%")
print("  按月记录条数:", monthly(hrv))

rv = vals(rhr)
if rv:
    print(f"\n【静息心率】n={len(rv)} 均值 {st.mean(rv):.1f} 标准差 {st.pstdev(rv):.1f}"
          f" 范围 {min(rv):.0f}–{max(rv):.0f}")

# ---- Workout ----
print(f"\n【训练记录】共 {len(workouts)} 次")
by_type = Counter(w.get("type", "?") for w in workouts)
for t, c in by_type.most_common():
    print(f"  {t:<46} {c:>4} 次")
print("  按月次数:", monthly(workouts))

durs = [num(w.get("duration")) for w in workouts]
durs = [d for d in durs if d is not None]
if durs:
    unit = workouts[0].get("durationUnit", "min")
    print(f"  时长：均值 {st.mean(durs):.1f} {unit}  中位 {st.median(durs):.1f}  范围 {min(durs):.0f}–{max(durs):.0f}")

ens = [num(w.get("totalEnergy")) for w in workouts]
ens = [e for e in ens if e is not None]
if ens:
    print(f"  总能量：均值 {st.mean(ens):.1f} {workouts[0].get('totalEnergyUnit','kcal')}"
          f"  范围 {min(ens):.0f}–{max(ens):.0f}")

# ---- 睡眠 ----
print(f"\n【睡眠】{len(sleep)} 条记录，覆盖 {coverage(sleep)} 天")
if sleep:
    sv = Counter(r.get("value", "?") for r in sleep)
    for k, v in sv.most_common(8):
        print(f"  {str(k)[:70]:<70} {v}")

# ---- 可行性判定 ----
print("\n" + "=" * 78)
print("可行性评估")
print("=" * 78)
hrv_days = coverage(hrv)
wk_days = coverage(workouts)
verdict = []
if hrv_days >= 100:
    verdict.append(("HRV 覆盖", "充足", f"{hrv_days} 天，可支撑个体内标准化与纵向建模"))
elif hrv_days >= 40:
    verdict.append(("HRV 覆盖", "基本可用", f"{hrv_days} 天，建议以周为单位聚合以降低噪声"))
else:
    verdict.append(("HRV 覆盖", "不足", f"{hrv_days} 天，需改用备选方案"))

if len(workouts) >= 60:
    verdict.append(("训练样本", "充足", f"{len(workouts)} 次，可做训练负荷特征"))
elif len(workouts) >= 25:
    verdict.append(("训练样本", "偏少但可用", f"{len(workouts)} 次，需限制特征维度"))
else:
    verdict.append(("训练样本", "不足", f"{len(workouts)} 次"))

for k, v, why in verdict:
    print(f"  [{v}] {k}：{why}")

json.dump({"span": [first, last, span_days], "report": report,
           "hrv_n": len(hv), "hrv_days": hrv_days,
           "hrv_stats": ({"mean": round(st.mean(hv), 2), "sd": round(st.pstdev(hv), 2),
                          "cv": round(st.pstdev(hv) / st.mean(hv) * 100, 1),
                          "min": min(hv), "max": max(hv)} if hv else None),
           "workout_n": len(workouts), "workout_types": dict(by_type),
           "sleep_n": len(sleep), "sleep_days": coverage(sleep),
           "rhr_stats": ({"mean": round(st.mean(rv), 2), "sd": round(st.pstdev(rv), 2)} if rv else None)},
          open(f"{OUT}/health_profile.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# 导出逐日特征表（建模用）
feat = defaultdict(dict)
for r in hrv:
    v = num(r.get("value"))
    if v is not None:
        feat[r["date"]].setdefault("hrv", []).append(v)
for r in rhr:
    v = num(r.get("value"))
    if v is not None:
        feat[r["date"]].setdefault("rhr", []).append(v)
for r in wrist:
    v = num(r.get("value"))
    if v is not None:
        feat[r["date"]].setdefault("wrist_temp", []).append(v)
for r in resp:
    v = num(r.get("value"))
    if v is not None:
        feat[r["date"]].setdefault("resp", []).append(v)
for r in daily:
    d = r["date"]
    for src, dst in [("hr_mean", "hr_mean"), ("hr_max", "hr_max"), ("active_energy", "active_energy"),
                     ("basal_energy", "basal_energy"), ("steps", "steps"),
                     ("distance", "distance"), ("exercise_min", "exercise_min")]:
        v = num(r.get(src))
        if v is not None:
            feat[d][dst] = v
for w in workouts:
    d = w["date"]
    feat[d]["workout_n"] = feat[d].get("workout_n", 0) + 1
    du = num(w.get("duration"))
    if du is not None:
        feat[d]["workout_min"] = feat[d].get("workout_min", 0) + du
    te = num(w.get("totalEnergy"))
    if te is not None:
        feat[d]["workout_kcal"] = feat[d].get("workout_kcal", 0) + te
    feat[d].setdefault("workout_type", []).append(w.get("type", ""))
# 睡眠时长
sl = defaultdict(float)
for r in sleep:
    try:
        a = r.get("startDate", "")[:19]
        b = r.get("endDate", "")[:19]
        from datetime import datetime
        fmt = "%Y-%m-%d %H:%M:%S"
        delta = (datetime.strptime(b, fmt) - datetime.strptime(a, fmt)).total_seconds() / 3600
        if 0 < delta < 24:
            sl[r["date"]] += delta
    except Exception:
        pass

cols = ["date", "hrv_mean", "hrv_n", "rhr", "resp", "wrist_temp", "hr_mean", "hr_max",
        "steps", "distance", "active_energy", "basal_energy", "exercise_min",
        "workout_n", "workout_min", "workout_kcal", "workout_type", "sleep_hours"]
with open(f"{OUT}/daily_features_p1.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=cols)
    w.writeheader()
    for d in sorted(feat):
        r = feat[d]
        hs = r.get("hrv", [])
        row = {"date": d,
               "hrv_mean": round(st.mean(hs), 2) if hs else "",
               "hrv_n": len(hs),
               "rhr": round(st.mean(r["rhr"]), 2) if r.get("rhr") else "",
               "resp": round(st.mean(r["resp"]), 2) if r.get("resp") else "",
               "wrist_temp": round(st.mean(r["wrist_temp"]), 3) if r.get("wrist_temp") else "",
               "hr_mean": r.get("hr_mean", ""), "hr_max": r.get("hr_max", ""),
               "steps": r.get("steps", ""), "distance": r.get("distance", ""),
               "active_energy": r.get("active_energy", ""), "basal_energy": r.get("basal_energy", ""),
               "exercise_min": r.get("exercise_min", ""),
               "workout_n": r.get("workout_n", 0), "workout_min": r.get("workout_min", ""),
               "workout_kcal": r.get("workout_kcal", ""),
               "workout_type": "|".join(sorted(set(r.get("workout_type", [])))),
               "sleep_hours": round(sl[d], 2) if sl.get(d) else ""}
        w.writerow(row)

print(f"\n逐日特征表已写出：daily_features.csv（{len(feat)} 天）")
