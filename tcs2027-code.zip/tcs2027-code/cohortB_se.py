# -*- coding: utf-8 -*-
"""Cohort B 三种负荷定义：聚类数与两种 SE 口径对照。"""
import json, os, math
from revision_checks import (load_pmdata, cohort_b, cluster_ols, plain_ols, zs,
                             MIN_PAIRS)
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
B = load_pmdata()

print("=" * 88)
print("Cohort B：三种负荷定义 × 两种 SE 口径")
print("=" * 88)
print(f"{'load':<8}{'n':>6}{'G':>5}{'beta':>10}{'t_plain':>9}{'t_cluster':>11}{'R2':>8}")
out = {}
for key in ("load", "vam", "mam"):
    r = cohort_b(B, key)
    z = r["z"]
    if not z:
        continue
    # 同一样本的 plain SE（集群内的朴素 SE），用于对照
    from revision_checks import load_pmdata as _l
    print(f"{key:<8}{z['n']:>6}{z['clusters']:>5}{z['coef'][1]['beta']:>10.4f}"
          f"{0:>9.2f}{z['coef'][1]['t']:>11.2f}{z['r2']:>8.3f}")
    out[key] = {"n": z["n"], "clusters": z["clusters"],
                "beta": round(z["coef"][1]["beta"], 4),
                "se_cluster": round(z["coef"][1]["se"], 4),
                "t_cluster": round(z["coef"][1]["t"], 2),
                "r2": round(z["r2"], 4)}

# 重新按同一逻辑取样本，算 plain SE
import csv, datetime as dt, statistics as st, re
PM = os.path.join(HERE, "pmdata")
subs = sorted(d for d in os.listdir(PM) if re.fullmatch(r"p\d\d", d))
keep = [p for p in subs if sum(1 for v in B[p].values() if v.get("load", 0) > 0) >= 20]
print(f"\nkeep 受试者（训练日≥20）：{len(keep)} 人")

for key in ("load", "vam", "mam"):
    rows = []
    for p in keep:
        dd = B[p]
        if sum(1 for v in dd.values() if key in v) < 30:
            continue
        ds = sorted(d for d in dd if "readiness" in dd[d])
        for i in range(1, len(ds)):
            d0, d1 = ds[i - 1], ds[i]
            try:
                g = (dt.date.fromisoformat(d1) - dt.date.fromisoformat(d0)).days
            except Exception:
                continue
            if g != 1:
                continue
            rows.append((p, dd[d0]["readiness"], dd[d0].get(key, 0.0), dd[d1]["readiness"]))
    bysub = defaultdict(list)
    for r in rows:
        bysub[r[0]].append(r)
    X, y, gg = [], [], []
    used = 0
    for p, rs in bysub.items():
        if len(rs) < 10:
            continue
        used += 1
        a = zs([r[1] for r in rs]); b = zs([r[2] for r in rs]); c = zs([r[3] for r in rs])
        for i in range(len(rs)):
            X.append([a[i], b[i]]); y.append(c[i]); gg.append(p)
    mc = cluster_ols(X, y, gg)
    mp = plain_ols(X, y)
    print(f"  {key:<6} n={mc['n']:>5}  contributors={used:>3}  "
          f"β={mc['coef'][1]['beta']:+.4f}  t_plain={mp['coef'][1]['t']:+.2f}  "
          f"t_cluster={mc['coef'][1]['t']:+.2f}  R²={mc['r2']:.4f}")
    out[key].update({"t_plain": round(mp["coef"][1]["t"], 2),
                     "contributors": used,
                     "n_rows": len(rows)})

json.dump(out, open(os.path.join(HERE, "cohortB_se.json"), "w"), ensure_ascii=False, indent=1)
print("\n已保存 cohortB_se.json")
