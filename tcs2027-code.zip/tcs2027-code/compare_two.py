#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
双受试者对比：量化「个体间差异」vs「个体内波动」，验证个体内标准化的必要性
核心指标：ICC（ intraclass correlation）、身份可识别度 AUC、建模策略对比
"""
import os
import csv, json, statistics as st
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))

BASE = HERE
P1 = f"{BASE}/daily_features_p1.csv"
P2 = os.path.join(HERE, "daily_features_p2.csv")


def load(p, tag):
    rows = list(csv.DictReader(open(p, encoding="utf-8-sig")))
    for r in rows:
        r["_id"] = tag
    return rows


A = load(P1, "P1")
B = load(P2, "P2")


def f(r, k):
    try:
        return float(r.get(k))
    except (TypeError, ValueError):
        return None


def series(rows, key):
    return {r["date"]: v for r in rows if (v := f(r, key)) is not None}


print("=" * 88)
print("一、两位受试者基本画像")
print("=" * 88)
prof = {}
for rows, tag, label in [(A, "P1", "受试者 A（你·业余健身）"), (B, "P2", "受试者 B（体育生）")]:
    hrv = series(rows, "hrv_mean"); rhr = series(rows, "rhr")
    sl = series(rows, "sleep_hours")
    wmin = series(rows, "workout_min")
    wtype = {}
    for r in rows:
        for t in (r.get("workout_type") or "").split("|"):
            if t:
                wtype[t] = wtype.get(t, 0) + int(r.get("workout_n") or 1)
    ds = sorted(r["date"] for r in rows)
    prof[tag] = {
        "label": label, "span": [ds[0], ds[-1]], "days": len(ds),
        "hrv_n": len(hrv), "hrv_mean": round(st.mean(hrv.values()), 2) if hrv else None,
        "hrv_sd_daily": round(st.pstdev(list(hrv.values())), 2) if hrv else None,
        "rhr_n": len(rhr), "rhr_mean": round(st.mean(rhr.values()), 2) if rhr else None,
        "rhr_sd": round(st.pstdev(list(rhr.values())), 2) if rhr else None,
        "sleep_mean": round(st.mean(sl.values()), 2) if sl else None,
        "workout_types": wtype,
    }
    print(f"\n{label}")
    print(f"  数据区间 {ds[0]} ~ {ds[-1]}（{len(ds)} 天）")
    if hrv:
        print(f"  HRV：{len(hrv)} 天，均值 {st.mean(hrv.values()):.1f} ms，"
              f"日间 SD {st.pstdev(list(hrv.values())):.2f}，"
              f"CV {st.pstdev(list(hrv.values()))/st.mean(hrv.values())*100:.1f}%")
    if rhr:
        print(f"  静息心率：{len(rhr)} 天，均值 {st.mean(rhr.values()):.1f} bpm，SD {st.pstdev(list(rhr.values())):.2f}")
    if sl:
        short = sum(1 for v in sl.values() if v < 7)
        print(f"  睡眠：{len(sl)} 天，均值 {st.mean(sl.values()):.2f} h，<7h 共 {short} 天（{short/len(sl)*100:.0f}%）")
    print("  训练类型：" + "、".join(f"{k.replace('HKWorkoutActivityType','')}×{v}"
                                    for k, v in sorted(wtype.items(), key=lambda x: -x[1])))
    if wmin:
        print(f"  训练时长：均值 {st.mean(wmin.values()):.1f} 分钟/次")

# ================= 二、ICC：个体间 vs 个体内 =================
print("\n" + "=" * 88)
print("二、方差分解：这些生理指标里，多少是「个体差异」，多少是「状态波动」？")
print("=" * 88)
print("  ICC = 个体间方差 / 总方差。ICC 越高，说明跨个体合并建模越会把「是谁」当成信号。")
print()
print(f"  {'指标':<12}{'ICC':>8}{'个体间SD':>10}{'个体内SD':>10}   解读")
print("  " + "-" * 68)

icc_res = {}
for key, label in [("hrv_mean", "HRV"), ("rhr", "静息心率"), ("sleep_hours", "睡眠时长"),
                   ("resp", "呼吸频率"), ("hr_mean", "日均心率")]:
    s1, s2 = series(A, key), series(B, key)
    common = sorted(set(s1) & set(s2))
    if len(common) < 40:
        continue
    g1 = [s1[d] for d in common]
    g2 = [s2[d] for d in common]
    m1, m2 = st.mean(g1), st.mean(g2)
    # 组内方差（个体内波动）
    w1 = st.pvariance(g1); w2 = st.pvariance(g2)
    msw = (w1 + w2) / 2
    # 组间方差（个体间差异）
    gm = (m1 + m2) / 2
    msb = ((m1 - gm) ** 2 + (m2 - gm) ** 2) / 1 * len(common)  # 组间平方和/自由度1
    # one-way random effects ICC(1)
    n0 = len(common)
    icc = (msb - msw) / (msb + (n0 - 1) * msw) if (msb + (n0 - 1) * msw) else 0
    icc = max(0.0, min(1.0, icc))
    between_sd = abs(m1 - m2) / (2 ** 0.5)
    within_sd = msw ** 0.5
    icc_res[key] = {"icc": round(icc, 3), "between_sd": round(between_sd, 2),
                    "within_sd": round(within_sd, 2), "n_common": len(common),
                    "A_mean": round(m1, 2), "B_mean": round(m2, 2)}
    verdict = ("个体差异主导 → 合并建模会学成'身份分类器'" if icc > 0.5 else
               ("个体差异显著，必须标准化" if icc > 0.2 else "个体差异小"))
    print(f"  {label:<12}{icc:>8.3f}{between_sd:>10.2f}{within_sd:>10.2f}   {verdict}")

# ================= 三、身份可识别度 AUC =================
print("\n" + "=" * 88)
print("三、身份可识别度：仅凭单日指标，能否判断「这是谁」？")
print("=" * 88)
print("  若 AUC 接近 1.0，说明跨个体差异远大于个体内变化 —— 这是必须做个体内标准化的硬证据。")
print()
print(f"  {'指标':<12}{'AUC':>8}   解读")
print("  " + "-" * 58)
auc_res = {}
for key, label in [("hrv_mean", "HRV"), ("rhr", "静息心率"), ("sleep_hours", "睡眠时长"),
                   ("resp", "呼吸频率"), ("hr_mean", "日均心率")]:
    s1, s2 = series(A, key), series(B, key)
    common = sorted(set(s1) & set(s2))
    if len(common) < 40:
        continue
    g1 = [s1[d] for d in common]
    g2 = [s2[d] for d in common]
    # Mann-Whitney U → AUC = P(x1 > x2)
    gt = tie = 0
    for x in g1:
        for y in g2:
            if x > y:
                gt += 1
            elif x == y:
                tie += 1
    auc = (gt + 0.5 * tie) / (len(g1) * len(g2))
    disc = max(auc, 1 - auc)   # 区分度与方向无关
    auc_res[key] = {"auc": round(auc, 3), "discriminability": round(disc, 3)}
    verdict = ("几乎完美区分 → 个体差异压倒性" if disc > 0.9 else
               ("高度可区分 → 个体差异占主导" if disc > 0.8 else
                ("中等可区分" if disc > 0.65 else "区分度有限")))
    print(f"  {label:<12}{auc:>8.3f}  区分度 {disc:.3f}  {verdict}")

# ================= 四、两各自的负荷—恢复效应（自回归） =================
print("\n" + "=" * 88)
print("四、各自的负荷—恢复效应（自回归模型，控制回归均值偏倚）")
print("=" * 88)


def ols(cols, y):
    n = len(y); names = list(cols)
    X = [[1.0] * n] + [cols[c] for c in names]; p = len(X)
    A = [[sum(X[i][t] * X[j][t] for t in range(n)) for j in range(p)] for i in range(p)]
    b = [sum(X[i][t] * y[t] for t in range(n)) for i in range(p)]
    m = p
    M = [A[i][:] + [1.0 if i == j else 0.0 for j in range(m)] + [b[i]] for i in range(m)]
    for c in range(m):
        piv = max(range(c, m), key=lambda r: abs(M[r][c]))
        if abs(M[piv][c]) < 1e-12:
            return None
        M[c], M[piv] = M[piv], M[c]
        d0 = M[c][c]; M[c] = [v / d0 for v in M[c]]
        for r in range(m):
            if r != c:
                fac = M[r][c]; M[r] = [M[r][cc] - fac * M[c][cc] for cc in range(len(M[r]))]
    beta = [M[i][-1] for i in range(m)]
    invd = [M[i][m + i] for i in range(m)]
    yhat = [sum(beta[i] * X[i][t] for i in range(p)) for t in range(n)]
    res = [y[t] - yhat[t] for t in range(n)]
    sse = sum(e * e for e in res); ybar = sum(y) / n
    sst = sum((v - ybar) ** 2 for v in y)
    s2 = sse / (n - p)
    se = [(s2 * invd[i]) ** 0.5 for i in range(p)]
    out = {"n": n, "r2": 1 - sse / sst if sst else 0, "resid_sd": s2 ** 0.5}
    for i, nm in enumerate(["(int)"] + names):
        out[nm] = {"beta": beta[i], "se": se[i], "t": beta[i] / se[i] if se[i] else 0}
    return out


def zs(vals):
    vs = list(vals.values())
    m = st.mean(vs); s = st.pstdev(vs) or 1e-9
    return {k: (v - m) / s for k, v in vals.items()}


eff_res = {}
for rows, tag, label in [(A, "P1", "受试者 A"), (B, "P2", "受试者 B")]:
    hrv = series(rows, "hrv_mean")
    rhr = series(rows, "rhr")
    sl = series(rows, "sleep_hours")
    wmin = {r["date"]: (f(r, "workout_min") or 0.0) for r in rows}
    Zh = zs(hrv); Zr = zs(rhr)
    all_dates = sorted(wmin)
    lmz = zs({d: wmin.get(d, 0.0) for d in all_dates})
    Zs = zs(sl) if len(sl) > 30 else {}
    for tgt_name, Zt in [("HRV", Zh), ("静息心率", Zr)]:
        ds = sorted(Zt)
        pairs = [(ds[i - 1], ds[i]) for i in range(1, len(ds))
                 if (date.fromisoformat(ds[i]) - date.fromisoformat(ds[i - 1])).days == 1]
        cols = {"auto": [Zt[d0] for d0, d1 in pairs],
                "load_z": [lmz.get(d0, 0.0) for d0, d1 in pairs],
                "sleep_z": [Zs.get(d0, 0.0) for d0, d1 in pairs]}
        y = [Zt[d1] for d0, d1 in pairs]
        M = ols(cols, y)
        if not M:
            continue
        # 换算：目标变量的原始 SD
        raw = hrv if tgt_name == "HRV" else rhr
        sd_raw = st.pstdev(list(raw.values()))
        M["load_z"]["se"] = M["load_z"]["se"]
        c = M["load_z"]
        mde = 2.802 * c["se"]
        eff_res[f"{tag}_{tgt_name}"] = {
            "n": M["n"], "r2": round(M["r2"], 3),
            "beta_z": round(c["beta"], 4), "se": round(c["se"], 4), "t": round(c["t"], 2),
            "ci": [round(c["beta"] - 1.96 * c["se"], 3), round(c["beta"] + 1.96 * c["se"], 3)],
            "beta_raw": round(c["beta"] * sd_raw, 3),
            "mde_z": round(mde, 3), "mde_raw": round(mde * sd_raw, 2),
            "detectable": bool(abs(c["t"]) > 1.96)}
        flag = "显著" if abs(c["t"]) > 1.96 else "不显著"
        print(f"\n  {label} · 目标={tgt_name}  n={M['n']}  R²={M['r2']:.3f}")
        print(f"    自回归 β={M['auto']['beta']:+.3f} (t={M['auto']['t']:+.2f})")
        print(f"    负荷   β={c['beta']:+.4f} SE={c['se']:.4f} t={c['t']:+.2f} "
              f"95%CI [{c['beta']-1.96*c['se']:+.3f},{c['beta']+1.96*c['se']:+.3f}] → {flag}")
        print(f"    MDE(power=.80) = {mde:.3f} z = {mde*sd_raw:.2f} 原始单位"
              f"；观测效应 {c['beta']*sd_raw:.2f} → "
              f"{'高于' if abs(c['beta'])>mde else '低于'}检出阈值")

# ================= 五、合并 vs 个体内：建模策略对比 =================
print("\n" + "=" * 88)
print("五、建模策略对比：合并建模 vs 个体内标准化（核心实验）")
print("=" * 88)
s1, s2 = series(A, "hrv_mean"), series(B, "hrv_mean")
common = sorted(set(s1) & set(s2))
if len(common) > 60:
    # 策略1：合并原始值（跨个体，不做标准化）
    pooled_raw = [s1[d] for d in common] + [s2[d] for d in common]
    # 策略2：个体内 z-score 后合并
    z1, z2 = zs(s1), zs(s2)
    pooled_z = [z1[d] for d in common] + [z2[d] for d in common]
    id_flag = [0] * len(common) + [1] * len(common)

    # 用「个体身份」解释多少方差
    def r2_of_group(values, flags):
        g0 = [v for v, fg in zip(values, flags) if fg == 0]
        g1 = [v for v, fg in zip(values, flags) if fg == 1]
        gm = st.mean(values)
        ssb = len(g0) * (st.mean(g0) - gm) ** 2 + len(g1) * (st.mean(g1) - gm) ** 2
        sst = sum((v - gm) ** 2 for v in values)
        return ssb / sst if sst else 0

    r2_raw = r2_of_group(pooled_raw, id_flag)
    r2_z = r2_of_group(pooled_z, id_flag)
    print(f"  共同日期 {len(common)} 天（{common[0]} ~ {common[-1]}）")
    print(f"\n  策略①：直接合并原始 HRV 值")
    print(f"    个体身份可解释的方差 R² = {r2_raw:.3f}  ← 模型学到的主要是'这是谁'")
    print(f"    合并后总方差 SD = {st.pstdev(pooled_raw):.2f} ms")
    print(f"\n  策略②：个体内 z-score 标准化后再合并")
    print(f"    个体身份可解释的方差 R² = {r2_z:.3f}  ← 身份信号被消除")
    print(f"    合并后总方差 SD = {st.pstdev(pooled_z):.3f}（标准化单位）")
    print(f"\n  → 个体内标准化使个体间方差占比从 {r2_raw*100:.1f}% 降至 {r2_z*100:.1f}%，"
          f"即移除了 {r2_raw*100:.0f} 个百分点的伪信号。")

    # 个体内变异占比
    w1 = st.pvariance([s1[d] for d in common]); w2 = st.pvariance([s2[d] for d in common])
    print(f"\n  补充：个体内日间波动 SD —— A {w1**0.5:.2f} ms，B {w2**0.5:.2f} ms；"
          f"个体间均值差 {abs(st.mean(list(s1.values()))-st.mean(list(s2.values()))):.1f} ms")
    print(f"        即：两人之间的基线差距，约为各自日常波动幅度的 "
          f"{abs(st.mean(list(s1.values()))-st.mean(list(s2.values())))/((w1**0.5+w2**0.5)/2):.1f} 倍。")

json.dump({"profile": prof, "icc": icc_res, "auc": auc_res, "effects": eff_res},
          open(f"{BASE}/compare_two.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("\n保存 compare_two.json")
