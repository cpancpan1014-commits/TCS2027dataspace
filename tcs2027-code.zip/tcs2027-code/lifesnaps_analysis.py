# -*- coding: utf-8 -*-
"""LifeSnaps 多受试者方差分解 + 负荷—恢复效应可检出性

目的
----
给 Cohort A（Apple Watch, n=2）的方差分解与负荷—恢复回归提供多受试者参照，
并检验自审式命题：「n=2 估出的 ICC 是否可靠」。

数据
----
LifeSnaps daily_fitbit_sema_df_unprocessed.csv
Yfantidou S, Karagianni C, Efstathiou S, et al.
LifeSnaps, a 4-month multi-modal dataset capturing unobtrusive snapshots of our
lives in the wild. Scientific Data 2022;9:663. DOI: 10.1038/s41597-022-01764-x
许可 CC BY 4.0

口径差异（正文必须写明）
------------------------
1) Apple Watch 记录的是 SDNN，LifeSnaps(Fitbit) 记录的是 RMSSD —— 指标不同；
2) 故跨设备的 ICC 数值不可直接等同，本分析的价值在于
   「同为消费者级可穿戴的日级指标，个体间/个体内方差比是否达到同一量级」；
3) 此处负荷为设备导出的活动分钟数（无 sRPE），属低信噪比代理，
   与 PMData 队列的 sRPE 形成效度梯度对比。
"""
import csv, json, math, os, statistics as st
from collections import defaultdict
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
CSV = os.path.join(HERE, "lifesnaps", "rais_anonymized", "csv_rais_anonymized",
                   "daily_fitbit_sema_df_unprocessed.csv")
OUT_JSON = os.path.join(HERE, "lifesnaps_result.json")

MIN_DAYS = 30      # 纳入方差分解的最小有效天数
MIN_PAIRS = 20     # 纳入回归的最小相邻日对数
T_TARGET = 2.80    # alpha=0.05 双侧 + 80% 功效的近似临界 t

# 单位换算：LifeSnaps 原始导出的时间字段存在不同量纲
UNIT_SCALE = {"sleep_duration": 1 / 3_600_000}       # 毫秒 -> 小时
# 生理上不可能为 0 的指标，0 值视为缺失（该类缺失占比 1.2%~3.1%，且不成簇）
ZERO_AS_MISSING = {"rmssd", "nremhr", "full_sleep_breathing_rate"}


# ---------------------------------------------------------------- 工具
def fnum(v):
    try:
        x = float(v)
        return x if x == x else None
    except Exception:
        return None


def zmap(d):
    """个体内 z-score，输入输出均为 dict"""
    vs = list(d.values())
    m, s = st.mean(vs), st.pstdev(vs) or 1e-9
    return {k: (v - m) / s for k, v in d.items()}


def days_gap(a, b):
    try:
        return (date.fromisoformat(b) - date.fromisoformat(a)).days
    except Exception:
        return 2


def icc_oneway(groups):
    """单向随机效应 ICC(1)，适配不等组大小（Shrout & Fleiss 情形 1）。

    ICC = (MSB - MSW) / (MSB + (n0 - 1) * MSW)，n0 为平均组大小的校正值。
    """
    ks = [g for g in groups.values() if len(g) >= 2]
    k = len(ks)
    if k < 2:
        return None
    N = sum(len(g) for g in ks)
    ns = [len(g) for g in ks]
    grand = st.mean([x for g in ks for x in g])
    ssb = sum(len(g) * (st.mean(g) - grand) ** 2 for g in ks)
    ssw = sum(sum((x - st.mean(g)) ** 2 for x in g) for g in ks)
    msb = ssb / (k - 1)
    msw = ssw / (N - k) if N - k > 0 else 1e-9
    n0 = (N - sum(n * n for n in ns) / N) / (k - 1)
    denom = msb + (n0 - 1) * msw
    if denom <= 0:
        return None
    return {"icc": (msb - msw) / denom,
            "between_sd": math.sqrt(max(0.0, (msb - msw) / n0)) if n0 > 0 else None,
            "within_sd": math.sqrt(msw),
            "k": k, "N": N, "n0": n0}


def rank_icc(groups):
    """基于秩的稳健版本 ICC：先把全部观测转成平均秩，再走同一套方差分解。
    用于交叉验证正态假设下的 ICC 是否被极端值带偏。"""
    flat = []
    for gid, g in groups.items():
        for x in g:
            flat.append((x, gid))
    flat.sort(key=lambda t: t[0])
    n = len(flat)
    ranks = defaultdict(list)
    i = 0
    while i < n:
        j = i
        while j + 1 < n and flat[j + 1][0] == flat[i][0]:
            j += 1
        r = (i + j + 2) / 2
        for t in range(i, j + 1):
            ranks[flat[t][1]].append(r)
        i = j + 1
    return icc_oneway(dict(ranks))


def solve(A, b):
    """解线性方程组并返回逆矩阵"""
    n = len(A)
    M = [A[i][:] + [b[i]] for i in range(n)]
    I = [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]
    for c in range(n):
        piv = max(range(c, n), key=lambda r: abs(M[r][c]))
        if abs(M[piv][c]) < 1e-12:
            return None, None
        M[c], M[piv] = M[piv], M[c]
        I[c], I[piv] = I[piv], I[c]
        pv = M[c][c]
        M[c] = [x / pv for x in M[c]]
        I[c] = [x / pv for x in I[c]]
        for r in range(n):
            if r != c:
                fac = M[r][c]
                if fac:
                    M[r] = [M[r][j] - fac * M[c][j] for j in range(n + 1)]
                    I[r] = [I[r][j] - fac * I[c][j] for j in range(n)]
    return [M[i][n] for i in range(n)], I


def cluster_ols(X, y, groups):
    """OLS + 按受试者聚类的稳健标准误（cluster-robust sandwich）。

    面板数据中同一人的残差自相关，朴素 SE 会高估显著性，此处必须用聚类版本。
    """
    n, k = len(y), len(X[0])
    Xd = [row + [1.0] for row in X]
    kk = k + 1
    XtX = [[sum(Xd[i][a] * Xd[i][b] for i in range(n)) for b in range(kk)] for a in range(kk)]
    Xty = [sum(Xd[i][a] * y[i] for i in range(n)) for a in range(kk)]
    beta, invXtX = solve(XtX, Xty)
    if beta is None:
        return None
    res = [y[i] - sum(beta[a] * Xd[i][a] for a in range(kk)) for i in range(n)]
    meat = [[0.0] * kk for _ in range(kk)]
    gmap = defaultdict(list)
    for i, g in enumerate(groups):
        gmap[g].append(i)
    G = len(gmap)
    for idx in gmap.values():
        sg = [sum(Xd[i][a] * res[i] for i in idx) for a in range(kk)]
        for a in range(kk):
            sa = sg[a]
            if sa == 0.0:
                continue
            for b in range(kk):
                meat[a][b] += sa * sg[b]
    corr = (G / (G - 1)) * ((n - 1) / (n - kk)) if G > 1 and n > kk else 1.0
    V = [[sum(invXtX[a][c] * meat[c][d] * invXtX[b][d]
              for c in range(kk) for d in range(kk)) * corr
          for b in range(kk)] for a in range(kk)]
    ym = st.mean(y)
    sst = sum((v - ym) ** 2 for v in y)
    sse = sum(e * e for e in res)
    coef = []
    for a in range(k):
        se = math.sqrt(max(V[a][a], 0.0))
        coef.append({"beta": beta[a], "se_cluster": se,
                     "t_cluster": beta[a] / se if se > 0 else 0.0})
    return {"coef": coef, "intercept": beta[kk - 1],
            "r2": 1 - sse / sst if sst > 0 else 0.0, "n": n, "clusters": G}


# ---------------------------------------------------------------- 载入
TARGETS = [
    ("rmssd",                     "HRV (RMSSD)"),
    ("resting_hr",                "静息心率"),
    ("nremhr",                    "NREM 心率"),
    ("sleep_duration",            "睡眠时长 (h)"),
    ("minutesAsleep",             "入睡分钟数"),
    ("stress_score",              "压力分数"),
    ("full_sleep_breathing_rate", "睡眠呼吸频率"),
    ("spo2",                      "血氧饱和度"),
    ("nightly_temperature",       "夜间腕温"),
    ("steps",                     "步数"),
    ("very_active_minutes",       "高强度活动分钟"),
    ("sedentary_minutes",         "久坐分钟"),
]

LOAD_KEYS = [
    ("very_active_minutes",       "高强度活动分钟"),
    ("moderately_active_minutes", "中等强度活动分钟"),
    ("lightly_active_minutes",    "轻度活动分钟"),
    ("steps",                     "步数"),
    ("calories",                  "卡路里"),
]


def load():
    rows = list(csv.DictReader(open(CSV, encoding="utf-8")))
    per = defaultdict(lambda: defaultdict(dict))
    meta = {}
    n_zero = 0
    for r in rows:
        uid, d = r.get("id"), r.get("date")
        if not uid or not d:
            continue
        dd = per[uid][d[:10]]
        for c, v in r.items():
            if c in ("id", "date", ""):
                continue
            x = fnum(v)
            if x is None:
                continue
            # 0 值缺失处理
            if c in ZERO_AS_MISSING and x == 0.0:
                n_zero += 1
                continue
            # 单位换算
            if c in UNIT_SCALE:
                x *= UNIT_SCALE[c]
            dd[c] = x
        if uid not in meta:
            meta[uid] = {"age_band": r.get("age"),          # 分类变量：<30 / >=30
                         "gender": r.get("gender"),
                         "bmi": fnum(r.get("bmi"))}
    print(f"已剔除生理不可能的 0 值 {n_zero} 条（涉及 {', '.join(sorted(v))}）")
    return per, meta


def build_pairs(per, load_key, target="rmssd"):
    """同一受试者内 z-score 标准化后，堆叠相邻日对。

    X = [当日目标值 z, 当日负荷 z]，y = 次日目标值 z
    负荷缺失日按 0 计（视为休息日），与 PMData 的处理保持一致。
    """
    X, y, g = [], [], []
    for uid, days in per.items():
        ds = sorted(days)
        tgt = {d: days[d][target] for d in ds if target in days[d]}
        if len(tgt) < MIN_PAIRS + 1:
            continue
        Zt = zmap(tgt)
        Zl = zmap({d: days[d].get(load_key, 0.0) for d in ds})
        pairs = [(ds[i - 1], ds[i]) for i in range(1, len(ds))
                 if days_gap(ds[i - 1], ds[i]) == 1]
        local = [(Zt[d0], Zl[d0], Zt[d1]) for d0, d1 in pairs
                 if d0 in Zt and d1 in Zt and d0 in Zl]
        if len(local) < MIN_PAIRS:
            continue
        for a, b, c in local:
            X.append([a, b]); y.append(c); g.append(uid)
    return X, y, g


def main():
    per, meta = load()
    res = {}
    print("=" * 72)
    print("LifeSnaps 多受试者方差分解")
    print("=" * 72)
    print(f"受试者 {len(per)} 人，日记录 {sum(len(v) for v in per.values())} 行\n")

    # ---------- 1. 方差分解 ----------
    print(f"【1】方差分解（单向随机效应 ICC，纳入 ≥ {MIN_DAYS} 有效天者）")
    print(f"  {'指标':<20}{'人数':>5}{'天数':>7}{'个体间SD':>10}{'个体内SD':>10}{'ICC':>8}{'秩ICC':>8}")
    var = {}
    for key, label in TARGETS:
        groups = {}
        for uid, days in per.items():
            vals = [v[key] for v in days.values() if key in v]
            if len(vals) >= MIN_DAYS:
                groups[uid] = vals
        if len(groups) < 3:
            continue
        ic = icc_oneway(groups)
        if ic is None:
            continue
        ri = rank_icc(groups)
        var[key] = {"label": label, **ic, "rank_icc": (ri or {}).get("icc")}
        print(f"  {label:<20}{ic['k']:>5}{ic['N']:>7}"
              f"{(ic['between_sd'] or 0):>10.2f}{ic['within_sd']:>10.2f}"
              f"{ic['icc']:>8.3f}{(ri or {}).get('icc', float('nan')):>8.3f}")
    res["variance"] = var

    # ---------- 2. 自审对照 ----------
    print("\n【2】自审对照：Apple n=2 描述性估计 vs 本队列 ICC 真值")
    apple = {("rmssd", "HRV"): 0.540,
             ("resting_hr", "静息心率"): 0.591,
             ("full_sleep_breathing_rate", "呼吸频率"): 0.906}
    cmp_rows = []
    print(f"  {'指标':<12}{'Apple n=2':>11}{'LifeSnaps':>11}{'人数':>6}{'高估倍数':>10}")
    for (key, lab), aval in apple.items():
        if key not in var:
            continue
        tv = var[key]["icc"]
        ratio = aval / tv if tv else None
        cmp_rows.append({"变量": lab, "Apple_n2描述值": aval,
                         "LifeSnaps_ICC": round(tv, 3), "n": var[key]["k"],
                         "高估倍数": round(ratio, 2) if ratio else None})
        print(f"  {lab:<12}{aval:>11.3f}{tv:>11.3f}{var[key]['k']:>6}"
              f"{(ratio if ratio else float('nan')):>10.2f}")
    res["self_audit"] = cmp_rows

    # ---------- 3. 负荷 → 次日 HRV ----------
    print(f"\n【3】负荷 → 次日 HRV：个体内 z-score + AR(1) 控制 + 聚类稳健 SE")
    print(f"  （纳入 ≥ {MIN_PAIRS} 相邻日对者；缺失负荷日按 0 计）")
    reg = []
    for key, label in LOAD_KEYS:
        X, y, g = build_pairs(per, key)
        if len(X) < 100:
            continue
        m = cluster_ols(X, y, g)
        if not m:
            continue
        c0, c1 = m["coef"]
        reg.append({"负荷定义": label, "key": key, "n_pairs": m["n"], "n_subj": m["clusters"],
                    "beta_auto": round(c0["beta"], 4), "t_auto": round(c0["t_cluster"], 2),
                    "beta_load": round(c1["beta"], 4), "se_load": round(c1["se_cluster"], 5),
                    "t_load": round(c1["t_cluster"], 2), "r2": round(m["r2"], 4)})
        print(f"  {label:<18} n={m['n']:>5} ({m['clusters']}人)   "
              f"自回归 β={c0['beta']:+.3f} (t={c0['t_cluster']:+.2f})   "
              f"负荷 β={c1['beta']:+.3f} (t={c1['t_cluster']:+.2f})   R²={m['r2']:.3f}")
    res["regression"] = reg

    # ---------- 4. 人口学能解释多少个体间差异 ----------
    # 注意：LifeSnaps 的 age 是匿名化后的分类型（<30 / >=30），不是连续值，
    #       故不能算 Pearson r，改用 eta²（组间 SS / 总体 SS，按个体均值计）。
    print("\n【4】个体基线偏移能否由人口学解释？（age 为分类变量，用 eta²）")
    dem = {}
    for key, label in [("rmssd", "HRV (RMSSD)"), ("resting_hr", "静息心率"),
                       ("sleep_duration", "睡眠时长 (h)")]:
        rows4 = []
        for uid, days in per.items():
            vals = [v[key] for v in days.values() if key in v]
            if len(vals) >= MIN_DAYS:
                rows4.append((uid, st.mean(vals)))
        if len(rows4) < 10:
            continue
        ys = [m for _, m in rows4]
        gm = st.mean(ys)
        sst = sum((y - gm) ** 2 for y in ys)
        for attr, alab in [("age_band", "年龄组(<30/>=30)"), ("gender", "性别")]:
            grp = defaultdict(list)
            for uid, m in rows4:
                a = meta.get(uid, {}).get(attr)
                if a:
                    grp[a].append(m)
            if len(grp) < 2:
                continue
            ssb = sum(len(v) * (st.mean(v) - gm) ** 2 for v in grp.values())
            eta2 = ssb / sst if sst > 0 else 0
            dem.setdefault(key, {"label": label, "n_subj": len(rows4)})[attr] = \
                {"label": alab, "groups": {k: len(v) for k, v in grp.items()},
                 "eta2_pct": round(eta2 * 100, 1)}
            print(f"  {label:<14} n={len(rows4):>3} 人  {alab:<18} "
                  f"可解释个体间差异 {eta2*100:5.1f}%   "
                  f"分组 {dict((k, len(v)) for k, v in grp.items())}")
    res["demography"] = dem

    # ---------- 5. 检出效益需要的受试者数 ----------
    # 面板数据下 t 值随聚类数 G 近似按 sqrt(G) 增长（每人的观测密度不变），
    # 故 G_need = G_now * (t_target / t_now)^2
    print("\n【5】检出观测效应所需的受试者数（保持每人观测密度不变）")
    power = []
    for r0 in reg:
        tnow = abs(r0["t_load"])
        if tnow <= 0:
            continue
        gneed = r0["n_subj"] * (T_TARGET / tnow) ** 2
        r0["need_subjects_80pct"] = round(gneed, 1)
        power.append(r0)
        print(f"  {r0['负荷定义']:<18} 当前 t={tnow:.2f} (n={r0['n_subj']} 人, "
              f"{r0['n_pairs']} 日对)  →  达 80% 功效需约 {gneed:.0f} 人")
    res["power"] = [{k: v for k, v in r0.items() if k in
                     ("负荷定义", "t_load", "n_subj", "n_pairs", "need_subjects_80pct")}
                    for r0 in power]

    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)
    print(f"\n已保存 {OUT_JSON}")


if __name__ == "__main__":
    main()
