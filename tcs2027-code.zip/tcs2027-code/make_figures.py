# -*- coding: utf-8 -*-
"""TCS2027 论文配图 Figure 1-5（v3：单栏 3.33 in，适配 ACM Word 双栏正文的栏内宽度）。

ACM Word 投稿模板正文为双栏，栏宽 3.33 in；跨栏图在 Word 中难以稳定实现，
故全部图按栏内宽度设计，布局相应调整（子图竖排、dumbbell 替代分组柱）。
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams
import numpy as np
import csv

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "figures")
os.makedirs(OUT, exist_ok=True)

rcParams["font.family"] = "DejaVu Sans"
rcParams["font.size"] = 7.5
rcParams["axes.labelsize"] = 7.5
rcParams["axes.titlesize"] = 8
rcParams["xtick.labelsize"] = 6.5
rcParams["ytick.labelsize"] = 6.5
rcParams["legend.fontsize"] = 6.2
rcParams["axes.linewidth"] = 0.6
rcParams["xtick.major.width"] = 0.5
rcParams["ytick.major.width"] = 0.5
rcParams["pdf.fonttype"] = 42
rcParams["ps.fonttype"] = 42

C_A = "#0072B2"
C_B = "#E69F00"
C_C = "#009E73"
C_GREY = "#999999"
C_RED = "#D55E00"

COL_W = 3.33  # ACM 双栏正文的栏宽


def load():
    with open(os.path.join(HERE, "compare_two.json"), encoding="utf-8") as f:
        c2 = json.load(f)
    with open(os.path.join(HERE, "lifesnaps_result.json"), encoding="utf-8") as f:
        ls = json.load(f)
    return c2, ls


def read_daily(path):
    out = {}
    with open(path, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            d = r.get("date", "")[:10]
            if d:
                out[d] = r
    return out


def save(fig, name):
    fig.savefig(os.path.join(OUT, name + ".png"), dpi=300, bbox_inches="tight")
    fig.savefig(os.path.join(OUT, name + ".pdf"), bbox_inches="tight")
    plt.close(fig)
    print("  " + name + " ok")


# ---------------------------------------------------------------- Figure 1
def fig1():
    """双人日序列 + 分布（竖排两个 panel）。"""
    p1 = read_daily(os.path.join(HERE, "daily_features_p1.csv"))
    p2 = read_daily(os.path.join(HERE, "p2", "daily_features_p1.csv"))
    dates = sorted(set(p1) & set(p2))

    def series(dic, key):
        ds, ys = [], []
        for d in dates:
            v = dic[d].get(key)
            if v not in (None, ""):
                try:
                    ys.append(float(v))
                    ds.append(d)
                except ValueError:
                    pass
        return ds, ys

    fig, axes = plt.subplots(
        2, 2, figsize=(COL_W, 2.70),
        gridspec_kw={"width_ratios": [3.0, 1], "wspace": 0.13, "hspace": 0.46})

    for row, (key, unit, title) in enumerate(
            (("hrv_mean", "ms", "HRV (SDNN)"), ("rhr", "bpm", "Resting heart rate"))):
        d1, y1 = series(p1, key)
        d2, y2 = series(p2, key)
        ax = axes[row, 0]
        ax.plot(np.arange(len(d1)), y1, lw=0.6, color=C_A)
        ax.plot(np.arange(len(d2)), y2, lw=0.6, color=C_B)
        ax.set_ylabel(unit)
        ax.set_title(title, loc="left", fontsize=8, pad=3)
        ax.margins(x=0.01)
        n = max(len(d1), len(d2))
        idx = np.linspace(0, n - 1, 5).round().astype(int)
        ax.set_xticks(idx)
        ax.set_xticklabels([dates[min(i, len(dates) - 1)][5:] for i in idx], fontsize=6)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        axb = axes[row, 1]
        bp = axb.boxplot([y1, y2], orientation="vertical", widths=0.55,
                         patch_artist=True, showfliers=False,
                         medianprops=dict(color="black", lw=0.8))
        for patch, col in zip(bp["boxes"], (C_A, C_B)):
            patch.set_facecolor(col)
            patch.set_alpha(0.55)
            patch.set_linewidth(0.6)
        for w_ in bp["whiskers"] + bp["caps"]:
            w_.set_linewidth(0.6)
        axb.set_ylim(ax.get_ylim())
        axb.set_xticks([1, 2])
        axb.set_xticklabels(["A", "B"], fontsize=6.5)
        axb.set_yticklabels([])
        axb.tick_params(axis="y", length=0)
        for s in ("top", "right", "left"):
            axb.spines[s].set_visible(False)

    handles = [plt.Line2D([], [], color=C_A, lw=1.3, label="Participant A (32 y)"),
               plt.Line2D([], [], color=C_B, lw=1.3, label="Participant B (21 y)")]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, 1.0),
               frameon=False, ncol=2, handlelength=1.3)
    fig.subplots_adjust(top=0.83)
    save(fig, "figure1_dyad_series")


# ---------------------------------------------------------------- Figure 2
def fig2(c2, ls):
    """三队列方差分解：dumbbell 图展示每个指标在队列间的跨度。"""
    rows = [
        ("Resting heart rate", 0.216, 0.591, 0.869),
        ("HRV", None, c2["icc"]["hrv_mean"]["icc"], ls["variance"]["rmssd"]["icc"]),
        ("Respiratory rate", None, c2["icc"]["resp"]["icc"],
         ls["variance"]["full_sleep_breathing_rate"]["icc"]),
        ("Sleep duration", None, c2["icc"]["sleep_hours"]["icc"],
         ls["variance"]["sleep_duration"]["icc"]),
    ]
    fig, ax = plt.subplots(figsize=(COL_W, 2.00))
    v_fmt = lambda v: f"{v:.3f}"
    y = np.arange(len(rows))
    for i, (lab, b, a, c) in enumerate(rows):
        vals = [v for v in (b, a, c) if v is not None]
        ax.plot([min(vals), max(vals)], [i, i], lw=1.0, color=C_GREY, zorder=1)
        bbox = dict(boxstyle="round,pad=0.12", fc="white", ec="none", alpha=0.85)
        if b is not None:
            ax.plot(b, i, "o", ms=4.5, color=C_B, label="Cohort B" if i == 0 else None,
                    zorder=3)
            ax.text(b, i - 0.27, f"{v_fmt(b)}", ha="center", fontsize=5.3,
                    color="#333333", bbox=bbox, zorder=4)
        ax.plot(a, i, "D", ms=4.5, color=C_A, label="Cohort A" if i == 0 else None,
                zorder=3)
        ax.text(a, i + 0.25, v_fmt(a), ha="center", fontsize=5.3,
                color="#333333", bbox=bbox, zorder=4)
        ax.plot(c, i, "s", ms=4.5, color=C_C, label="Cohort C" if i == 0 else None,
                zorder=3)
        ax.text(c, i - 0.27, v_fmt(c), ha="center", fontsize=5.3,
                color="#333333", bbox=bbox, zorder=4)
    ax.set_yticks(y)
    ax.set_yticklabels([r[0] for r in rows], fontsize=6.5)
    ax.invert_yaxis()
    ax.set_xlabel("Between-person share of variance")
    ax.set_xlim(-0.05, 1.12)
    ax.set_ylim(len(rows) - 0.42, -0.72)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    # 静息心率跨度标注
    ax.annotate("", xy=(0.869, -0.36), xytext=(0.216, -0.36),
                arrowprops=dict(arrowstyle="<->", color=C_RED, lw=1.0))
    ax.text(0.542, -0.50, "4\u00d7 range", fontsize=6, color=C_RED, ha="center",
            weight="bold", bbox=dict(boxstyle="round,pad=0.15", fc="white",
                                     ec="none", alpha=0.9))
    leg = ax.legend(loc="lower right", frameon=False, ncol=1, handlelength=1.1)
    for t in leg.get_texts():
        t.set_fontsize(6)
    fig.tight_layout()
    save(fig, "figure2_variance_three_cohorts")


# ---------------------------------------------------------------- Figure 3
def fig3():
    """个体内标准化（竖排两 panel）。"""
    labels = ["HRV", "Resting HR", "Respiratory"]
    pooled = [54.1, 59.2, 90.7]

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(COL_W, 2.80),
                                   gridspec_kw={"hspace": 0.65})
    x = np.arange(len(labels))
    w = 0.35
    ax1.bar(x - w / 2, pooled, w, label="Raw values pooled", color=C_A,
            edgecolor="white", linewidth=0.5)
    ax1.bar(x + w / 2, [0, 0, 0], w, label="Within-subject z", color=C_GREY,
            edgecolor="white", linewidth=0.5)
    for i, v in enumerate(pooled):
        ax1.text(i - w / 2, v + 2, f"{v:.1f}%", ha="center", fontsize=6)
    for i in range(len(labels)):
        ax1.text(i + w / 2, 2, "0.0%", ha="center", fontsize=6)
    ax1.set_xticks(x)
    ax1.set_xticklabels(labels, fontsize=6.5)
    ax1.set_ylabel("Between-person variance share (%)")
    ax1.set_ylim(0, 118)
    ax1.text(1.0, 1.03, "grey = after z-scoring", transform=ax1.transAxes,
             fontsize=5.5, color=C_GREY, ha="right", va="bottom")
    ax1.spines["top"].set_visible(False)
    ax1.spines["right"].set_visible(False)
    ax1.set_title("(a) Variance removed", loc="left", fontsize=8)

    r2 = [0.249, 0.090]
    tvals = [5.03, 5.94]
    ax2.bar([0, 1], r2, 0.34, color=C_GREY, edgecolor="white")
    for i, v in enumerate(r2):
        ax2.text(i, v + 0.008, f"{v:.3f}", ha="center", fontsize=6)
    ax2.set_ylabel("R\u00b2", fontsize=7)
    ax2.set_ylim(0, 0.33)
    ax2.set_xticks([0, 1])
    ax2.set_xticklabels(["Raw pooled", "Within-subject z"], fontsize=6.5)
    ax2b = ax2.twinx()
    ax2b.plot([0, 1], tvals, "o-", color=C_RED, lw=1.2, markersize=4.2)
    ax2b.set_ylabel("|t| (load coefficient)", color=C_RED, fontsize=7)
    ax2b.set_ylim(4.4, 6.6)
    ax2b.tick_params(axis="y", colors=C_RED, labelsize=6.5)
    for i, t in enumerate(tvals):
        ax2b.annotate(f"{t:.2f}", (i, t), textcoords="offset points",
                      xytext=(0, 6), ha="center", fontsize=6, color=C_RED)
    ax2.spines["top"].set_visible(False)
    ax2b.spines["top"].set_visible(False)
    ax2.set_title("(b) Fit falls, precision rises", loc="left", fontsize=8)
    fig.subplots_adjust(top=0.90)
    save(fig, "figure3_normalization")


# ---------------------------------------------------------------- Figure 4
def fig4(c2, ls):
    """森林图（竖排，标签缩短）。"""
    def ci(b, se):
        return b - 1.96 * se, b + 1.96 * se

    eff = c2["effects"]
    rows = []
    rows.append(("A: HRV", eff["P1_HRV"]["beta_z"], eff["P1_HRV"]["ci"][0],
                 eff["P1_HRV"]["ci"][1], "A"))
    rows.append(("A: resting HR", eff["P1_\u9759\u606f\u5fc3\u7387"]["beta_z"],
                 eff["P1_\u9759\u606f\u5fc3\u7387"]["ci"][0],
                 eff["P1_\u9759\u606f\u5fc3\u7387"]["ci"][1], "A"))
    rows.append(("B: HRV", eff["P2_HRV"]["beta_z"], eff["P2_HRV"]["ci"][0],
                 eff["P2_HRV"]["ci"][1], "A"))
    rows.append(("B: resting HR", eff["P2_\u9759\u606f\u5fc3\u7387"]["beta_z"],
                 eff["P2_\u9759\u606f\u5fc3\u7387"]["ci"][0],
                 eff["P2_\u9759\u606f\u5fc3\u7387"]["ci"][1], "A"))
    for lab, b, t in (("B: readiness \u2190 sRPE", -0.210, -6.43),
                      ("B: readiness \u2190 active min", -0.141, -4.69),
                      ("B: readiness \u2190 mod. min", -0.074, -2.53)):
        lo, hi = ci(b, abs(b / t))
        rows.append((lab, b, lo, hi, "B"))
    lab_map = {"\u5361\u8def\u91cc": "C: RMSSD \u2190 calories",
               "\u9ad8\u5f3a\u5ea6\u6d3b\u52a8\u5206\u949f": "C: RMSSD \u2190 active min",
               "\u6b65\u6570": "C: RMSSD \u2190 steps",
               "\u4e2d\u7b49\u5f3a\u5ea6\u6d3b\u52a8\u5206\u949f": "C: RMSSD \u2190 mod. min",
               "\u8f7b\u5ea6\u6d3b\u52a8\u5206\u949f": "C: RMSSD \u2190 light min"}
    for r in ls["regression"]:
        if r["\u8d1f\u8377\u5b9a\u4e49"] in lab_map:
            lo, hi = ci(r["beta_load"], r["se_load"])
            rows.append((lab_map[r["\u8d1f\u8377\u5b9a\u4e49"]], r["beta_load"], lo, hi, "C"))
    rows.reverse()
    color_of = {"A": C_A, "B": C_B, "C": C_C}

    fig, ax = plt.subplots(figsize=(COL_W, 2.90))
    y = np.arange(len(rows))
    for i, (_, b, lo, hi, co) in enumerate(rows):
        sig = not (lo < 0 < hi)
        ax.plot([lo, hi], [i, i], lw=1.1, color=color_of[co], solid_capstyle="butt")
        ax.plot(b, i, "s" if sig else "o", ms=4.0 if sig else 3.2,
                color=color_of[co], markeredgecolor="white", markeredgewidth=0.5)
    ax.axvline(0, color="black", lw=0.7, ls="--")
    ax.set_yticks(y)
    ax.set_yticklabels([r[0] for r in rows], fontsize=6.0)
    ax.set_xlabel("Standardised load effect (\u03b2, z units)", fontsize=7)
    ax.set_xlim(-0.34, 0.27)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    handles = [plt.Line2D([], [], color=C_A, lw=1.8, label="Cohort A (n = 1)"),
               plt.Line2D([], [], color=C_B, lw=1.8, label="Cohort B (n = 11)"),
               plt.Line2D([], [], color=C_C, lw=1.8, label="Cohort C (n = 36)"),
               plt.Line2D([], [], color="black", marker="s", ls="none", ms=4,
                          label="significant (\u25a0)")]
    leg = fig.legend(handles=handles, loc="lower center",
                     bbox_to_anchor=(0.5, -0.005), frameon=False, ncol=2,
                     handlelength=1.4, columnspacing=1.2)
    for t in leg.get_texts():
        t.set_fontsize(5.8)
    fig.subplots_adjust(bottom=0.20)
    save(fig, "figure4_forest")


# ---------------------------------------------------------------- Figure 5
def fig5(ls):
    """所需人数。"""
    en = {"\u5361\u8def\u91cc": "Calories",
          "\u9ad8\u5f3a\u5ea6\u6d3b\u52a8\u5206\u949f": "Very-active min",
          "\u6b65\u6570": "Steps",
          "\u4e2d\u7b49\u5f3a\u5ea6\u6d3b\u52a8\u5206\u949f": "Moderate min",
          "\u8f7b\u5ea6\u6d3b\u52a8\u5206\u949f": "Light min"}
    rows = [r for r in ls["regression"] if r["\u8d1f\u8377\u5b9a\u4e49"] in en]
    rows.sort(key=lambda r: r["need_subjects_80pct"])
    names = [en[r["\u8d1f\u8377\u5b9a\u4e49"]] for r in rows]
    need = [r["need_subjects_80pct"] for r in rows]
    betas = [r["beta_load"] for r in rows]

    fig, ax = plt.subplots(figsize=(COL_W, 2.15))
    y = np.arange(len(names))
    colors = [C_C if n < 12 else ("#56B4E9" if n < 21 else C_B) for n in need]
    ax.barh(y, need, color=colors, edgecolor="white", linewidth=0.5, height=0.6)
    for i, (n, b) in enumerate(zip(need, betas)):
        ax.text(n + 0.5, i, f"{n:.0f}  (\u03b2={b:+.3f})", va="center", fontsize=6)
    ax.set_yticks(y)
    ax.set_yticklabels(names, fontsize=6.5)
    ax.invert_yaxis()
    ax.set_xlabel("Participants required for 80% power", fontsize=7)
    ax.set_xlim(0, 41)
    ax.axvline(2, color=C_RED, lw=1.0, ls="--")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.set_title("All five significant; cost differs 3.5\u00d7", loc="left", fontsize=7.5)
    # 参考线标签置于轴外底部，彻底避开条形
    ax.text(0.01, -0.30, "Cohort A: n = 2", transform=ax.transAxes,
            color=C_RED, fontsize=6, va="top", ha="left", weight="bold")
    ax.text(0.99, -0.30, "Cohort C: n = 36", transform=ax.transAxes,
            color="black", fontsize=6, va="top", ha="right")
    fig.subplots_adjust(bottom=0.30)
    save(fig, "figure5_required_participants")


def main():
    c2, ls = load()
    print("Generating single-column figures ->", OUT)
    fig1()
    fig2(c2, ls)
    fig3()
    fig4(c2, ls)
    fig5(ls)
    print("done.")


if __name__ == "__main__":
    main()
