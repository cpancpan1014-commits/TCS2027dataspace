# -*- coding: utf-8 -*-
"""PMData (n=16) 分析：真正的多受试者方差分解 + 负荷→次日主观恢复建模。
对照 Apple Watch n=2 个案，检验「个体间偏移 vs 个体内波动」这一核心主张。
"""
import csv, json, os, statistics as st, zipfile, re, datetime as dt

HERE = os.path.dirname(os.path.abspath(__file__))

D = HERE + "/pmdata"
OUT = HERE
def read_xlsx_min(path):
    """极简 xlsx 解析：返回 list[list[str]]"""
    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True)
        ws = wb[wb.sheetnames[0]]
        return [[str(c.value) if c.value is not None else "" for c in row] for row in ws.iter_rows()]
    except Exception:
        pass
    with zipfile.ZipFile(path) as z:
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            s = z.read("xl/sharedStrings.xml").decode("utf-8", "ignore")
            shared = [re.sub(r"<.*?>", "", m) for m in re.findall(r"<si>(.*?)</si>", s, re.S)]
        sheet = z.read("xl/worksheets/sheet1.xml").decode("utf-8", "ignore")
    rows = []
    for r in re.findall(r"<row[^>]*>(.*?)</row>", sheet, re.S):
        cells = {}
        for c in re.findall(r'<c r="([A-Z]+)\d+"([^>]*)>(.*?)</c>|<c r="([A-Z]+)\d+"([^>]*)/>', r, re.S):
            pass
        vals = []
        for m in re.finditer(r'<c r="([A-Z]+)\d+"([^>]*?)(?:/>|>(.*?)</c>)', r, re.S):
            col, attr, inner = m.group(1), m.group(2), m.group(3) or ""
            tv = re.search(r't="([^"]+)"', attr)
            v = re.search(r"<v>(.*?)</v>", inner, re.S)
            val = v.group(1) if v else ""
            if tv and tv.group(1) == "s" and val.isdigit():
                val = shared[int(val)] if int(val) < len(shared) else val
            vals.append((col, val))
        if vals:
            rows.append([v for _, v in sorted(vals, key=lambda x: len(x[0]) * 100 + ord(x[0][0]))])
    return rows


def num(x):
    try:
        return float(x)
    except Exception:
        return None


def load_participant(p):
    """返回 {date: {...}}"""
    day = {}

    w = os.path.join(D, p, "pmsys", "wellness.csv")
    if os.path.exists(w):
        with open(w, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                d = (r.get("effective_time_frame") or "")[:10]
                if not d:
                    continue
                e = day.setdefault(d, {})
                for k in ("fatigue", "mood", "readiness", "sleep_quality", "soreness", "stress"):
                    v = num(r.get(k))
                    if v is not None:
                        e[k] = v
                v = num(r.get("sleep_duration_h"))
                if v is not None:
                    e["sleep_h"] = v

    s = os.path.join(D, p, "pmsys", "srpe.csv")
    if os.path.exists(s):
        with open(s, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                d = (r.get("end_date_time") or "")[:10]
                rpe, dur = num(r.get("perceived_exertion")), num(r.get("duration_min"))
                if not d or rpe is None or dur is None:
                    continue
                day.setdefault(d, {})
                day[d]["load"] = day[d].get("load", 0.0) + rpe * dur
                day[d]["sessions"] = day[d].get("sessions", 0) + 1

    r = os.path.join(D, p, "fitbit", "resting_heart_rate.json")
    if os.path.exists(r):
        try:
            for it in json.load(open(r, encoding="utf-8")):
                d = (it.get("dateTime") or "")[:10]
                v = (it.get("value") or {}).get("value")
                if d and isinstance(v, (int, float)):
                    day.setdefault(d, {})["rhr"] = float(v)
        except Exception:
            pass

    # 设备自身导出的活动量（用来和 sRPE 对照）
    for fn, key in [("very_active_minutes.json", "vam"),
                    ("moderately_active_minutes.json", "mam")]:
        fp = os.path.join(D, p, "fitbit", fn)
        if not os.path.exists(fp):
            continue
        try:
            for it in json.load(open(fp, encoding="utf-8")):
                d = (it.get("dateTime") or "")[:10]
                v = it.get("value")
                try:
                    v = float(v)
                except (TypeError, ValueError):
                    continue
                if d:
                    day.setdefault(d, {})[key] = v
        except Exception:
            pass

    ss = os.path.join(D, p, "fitbit", "sleep_score.csv")
    if os.path.exists(ss):
        with open(ss, encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                d = (row.get("timestamp") or row.get("date") or "")[:10]
                v = num(row.get("overall_score") or row.get("sleep_score"))
                if d and v is not None:
                    day.setdefault(d, {})["sleep_score"] = v
    return day


def icc_decomp(series_by_subject):
    """series_by_subject: {subj: [values]} -> (icc, between_sd, within_sd)"""
    subs = {k: v for k, v in series_by_subject.items() if len(v) >= 20}
    if len(subs) < 3:
        return None
    means = [st.mean(v) for v in subs.values()]
    n = st.mean([len(v) for v in subs.values()])
    sb2 = st.variance(means) if len(means) > 1 else 0.0
    sw2 = st.mean([st.variance(v) for v in subs.values() if len(v) > 1])
    sb2_adj = max(0.0, sb2 - sw2 / n)
    tot = sb2_adj + sw2
    return {"icc": sb2_adj / tot if tot > 0 else 0.0,
            "between_sd": sb2_adj ** 0.5, "within_sd": sw2 ** 0.5,
            "n_subj": len(subs), "mean_days": round(n, 1),
            "grand_mean": round(st.mean([x for v in subs.values() for x in v]), 2)}


def ols(X, y):
    """最小二乘（含截距）：Gauss-Jordan 求 [X'X]^-1，返回 beta / se / t / R²"""
    n, k = len(y), len(X[0])
    if n <= k + 1:
        return None
    A = [[sum(X[i][a] * X[i][b] for i in range(n)) for b in range(k)] for a in range(k)]
    b = [sum(X[i][a] * y[i] for i in range(n)) for a in range(k)]
    # 增广 [A | I | b]，做带归一化的 Gauss-Jordan
    M = [A[i][:] + [1.0 if j == i else 0.0 for j in range(k)] + [b[i]] for i in range(k)]
    for c in range(k):
        piv = max(range(c, k), key=lambda r: abs(M[r][c]))
        if abs(M[piv][c]) < 1e-10:
            return None
        M[c], M[piv] = M[piv], M[c]
        pv = M[c][c]
        M[c] = [v / pv for v in M[c]]
        for r in range(k):
            if r != c and M[r][c] != 0.0:
                f = M[r][c]
                M[r] = [M[r][j] - f * M[c][j] for j in range(2 * k + 1)]
    beta = [M[i][2 * k] for i in range(k)]
    inv = [[M[i][k + j] for j in range(k)] for i in range(k)]
    res = [y[i] - sum(beta[a] * X[i][a] for a in range(k)) for i in range(n)]
    s2 = sum(e * e for e in res) / (n - k)
    ss = sum((v - st.mean(y)) ** 2 for v in y)
    r2 = 1 - sum(e * e for e in res) / ss if ss > 0 else 0.0
    coef = []
    for a in range(k):
        v = s2 * inv[a][a]
        se = v ** 0.5 if v > 0 else 0.0
        coef.append({"beta": beta[a], "se": se, "t": (beta[a] / se if se > 0 else 0.0)})
    return {"coef": coef, "r2": r2, "n": n}


if __name__ == "__main__":
    subs = sorted(d for d in os.listdir(D) if re.fullmatch(r"p\d\d", d))
    data = {p: load_participant(p) for p in subs}
    print("=" * 68)
    print("PMData 载入（n=%d）" % len(subs))
    print("=" * 68)
    for p in subs:
        dd = data[p]
        rd = sum(1 for v in dd.values() if "readiness" in v)
        ld = sum(1 for v in dd.values() if "load" in v)
        rh = sum(1 for v in dd.values() if "rhr" in v)
        print(f"  {p}  天数 {len(dd):>4}  readiness {rd:>4}  有训练 {ld:>4}  静息心率 {rh:>4}")

    print("\n" + "=" * 68)
    print("一、方差分解（这次 n=16，ICC 是真参数）")
    print("=" * 68)
    varres = {}
    for key, label in [("readiness", "主观恢复 readiness"), ("rhr", "静息心率"), ("fatigue", "疲劳"), ("stress", "压力")]:
        s = {p: [v[key] for v in data[p].values() if key in v] for p in subs}
        r = icc_decomp(s)
        if not r:
            continue
        varres[key] = r
        print(f"  {label:<16} ICC={r['icc']:.3f}  个体间SD={r['between_sd']:.3f}  "
              f"个体内SD={r['within_sd']:.3f}  (受试者 {r['n_subj']}, 均 {r['mean_days']} 天)")

    print("\n" + "=" * 68)
    print("二、个体间基线偏移 = 多少个个体内 SD")
    print("=" * 68)
    for key in ("readiness", "rhr"):
        s = {p: [v[key] for v in data[p].values() if key in v] for p in subs}
        ms = {p: st.mean(v) for p, v in s.items() if len(v) >= 20}
        if len(ms) < 3:
            continue
        wsd = st.mean([st.pstdev(s[p]) for p in ms])
        lo, hi = min(ms.values()), max(ms.values())
        print(f"  {key:<12} 个体均值范围 {lo:.2f} ~ {hi:.2f}  跨度 {hi-lo:.2f}  "
              f"平均个体内SD {wsd:.3f}  → 跨度 = {(hi-lo)/wsd:.2f} 个个体内SD")
        print(f"                最低 {min(ms,key=ms.get)} / 最高 {max(ms,key=ms.get)}")

    print("\n" + "=" * 68)
    print("三、负荷 → 次日主观恢复（两种建模口径对比）")
    print("=" * 68)
    # 负荷—恢复建模只保留训练日足够多的受试者（否则负荷近乎无变异，系数不可估）
    train_days = {p: sum(1 for v in data[p].values() if v.get("load", 0) > 0) for p in subs}
    keep = [p for p in subs if train_days[p] >= 20]
    print(f"  训练日 ≥20 天的受试者：{len(keep)}/{len(subs)} 人  {keep}\n")
    rows_raw, rows_z = [], []
    for p in keep:
        dd = data[p]
        ds = sorted(d for d in dd if "readiness" in dd[d])
        for i in range(1, len(ds)):
            d0, d1 = ds[i - 1], ds[i]
            if (dt.date.fromisoformat(d1) - dt.date.fromisoformat(d0)).days != 1:
                continue
            y0, y1 = dd[d0]["readiness"], dd[d1]["readiness"]
            load = dd[d0].get("load", 0.0)
            rows_raw.append((p, y0, load, y1))
    # 原始口径：合并所有受试者，不区分个体
    if len(rows_raw) > 60:
        X = [[1.0, r[1], r[2]] for r in rows_raw]
        y = [r[3] for r in rows_raw]
        m = ols(X, y)
        print(f"  [A] 合并原始值（忽视个体）  n={m['n']}  R²={m['r2']:.4f}")
        print(f"      当日 readiness β={m['coef'][1]['beta']:.4f} (t={m['coef'][1]['t']:.2f})  "
              f"负荷 β={m['coef'][2]['beta']:.5f} (t={m['coef'][2]['t']:.2f})")
    # 个体内 z 标准化后
    bysub = {}
    for p, y0, load, y1 in rows_raw:
        bysub.setdefault(p, []).append((y0, load, y1))
    def zs(vs):
        m, s = st.mean(vs), st.pstdev(vs) or 1e-9
        return [(v - m) / s for v in vs]
    X2, y2 = [], []
    for p, rs in bysub.items():
        if len(rs) < 10:
            continue
        y0s, ls, y1s = zs([r[0] for r in rs]), zs([r[1] for r in rs]), zs([r[2] for r in rs])
        for a, b, c in zip(y0s, ls, y1s):
            X2.append([1.0, a, b]); y2.append(c)
    if len(y2) > 60:
        m2 = ols(X2, y2)
        print(f"  [B] 个体内 z 标准化后      n={m2['n']}  R²={m2['r2']:.4f}")
        print(f"      当日 readiness β={m2['coef'][1]['beta']:.4f} (t={m2['coef'][1]['t']:.2f})  "
              f"负荷 β={m2['coef'][2]['beta']:.4f} (t={m2['coef'][2]['t']:.2f})")

    print("\n" + "=" * 68)
    print("四、决定性实验：负荷的「操作化方式」决定能不能检出效应")
    print("=" * 68)
    print("  同一批人、同一目标变量，只换负荷的定义：")
    specs = [("sRPE 负荷（RPE×时长）", "load"),
             ("设备导出·高强度活动分钟", "vam"),
             ("设备导出·中等强度活动分钟", "mam")]
    cmp_res = {}
    for label, key in specs:
        rows = []
        for p in keep:
            dd = data[p]
            if sum(1 for v in dd.values() if key in v) < 30:
                continue
            ds = sorted(d for d in dd if "readiness" in dd[d])
            for i in range(1, len(ds)):
                d0, d1 = ds[i - 1], ds[i]
                if (dt.date.fromisoformat(d1) - dt.date.fromisoformat(d0)).days != 1:
                    continue
                rows.append((p, dd[d0]["readiness"], dd[d0].get(key, 0.0), dd[d1]["readiness"]))
        bysub = {}
        for p, a, b, c in rows:
            bysub.setdefault(p, []).append((a, b, c))
        X3, y3 = [], []
        for p, rs in bysub.items():
            if len(rs) < 10:
                continue
            a_ = zs([r[0] for r in rs]); b_ = zs([r[1] for r in rs]); c_ = zs([r[2] for r in rs])
            for u, v, w in zip(a_, b_, c_):
                X3.append([1.0, u, v]); y3.append(w)
        if len(y3) < 60:
            print(f"  {label:<26} 样本不足（n={len(y3)}），跳过")
            continue
        m3 = ols(X3, y3)
        b_load = m3["coef"][2]
        cmp_res[key] = {"label": label, "n": m3["n"], "r2": round(m3["r2"], 4),
                        "beta": round(b_load["beta"], 4), "t": round(b_load["t"], 2)}
        sig = "显著" if abs(b_load["t"]) > 1.96 else "不显著"
        print(f"  {label:<26} n={m3['n']:>5}  R²={m3['r2']:.4f}  "
              f"负荷 β={b_load['beta']:+.4f}  t={b_load['t']:+.2f}  [{sig}]")

    json.dump({"variance": varres, "n_pairs_raw": len(rows_raw), "n_pairs_z": len(y2),
               "load_operationalization": cmp_res},
              open(os.path.join(OUT, "pmdata_result.json"), "w"), indent=1)
    print("\n已保存 pmdata_result.json")
