#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数据质量检查：异常值、缺失模式、分布形态"""
import os
import csv, statistics as st, json
from collections import Counter
from datetime import date, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))

P = HERE + "/daily_features_p1.csv"
rows = list(csv.DictReader(open(P, encoding="utf-8-sig")))


def col(name):
    out = []
    for r in rows:
        v = r.get(name, "")
        try:
            out.append((r["date"], float(v)))
        except (TypeError, ValueError):
            pass
    return out


def stats(name):
    c = col(name)
    vs = [v for _, v in c]
    if not vs:
        return None
    vs_s = sorted(vs)
    n = len(vs)
    q = lambda p: vs_s[min(n - 1, int(p * n))]
    return {"n": n, "mean": round(st.mean(vs), 2), "sd": round(st.pstdev(vs), 2),
            "min": round(min(vs), 2), "p05": round(q(.05), 2), "q1": round(q(.25), 2),
            "med": round(st.median(vs), 2), "q3": round(q(.75), 2),
            "p95": round(q(.95), 2), "max": round(max(vs), 2),
            "cv": round(st.pstdev(vs) / st.mean(vs) * 100, 1) if st.mean(vs) else None}


print("=" * 84)
print("逐日特征分布（2026 年，共 %d 天）" % len(rows))
print("=" * 84)
print(f"{'变量':<16}{'n':>5}{'均值':>9}{'标准差':>9}{'CV%':>7}{'最小':>8}{'P5':>8}{'中位':>8}{'P95':>8}{'最大':>9}")
print("-" * 84)
S = {}
for name, label in [("hrv_mean", "HRV(ms)"), ("rhr", "静息心率"), ("hr_mean", "日均心率"),
                    ("hr_max", "日峰值心率"), ("resp", "呼吸频率"), ("wrist_temp", "腕温"),
                    ("steps", "步数"), ("distance", "距离km"), ("active_energy", "活动能量"),
                    ("exercise_min", "锻炼分钟"), ("workout_min", "训练分钟"),
                    ("workout_kcal", "训练kcal"), ("sleep_hours", "睡眠小时")]:
    s = stats(name)
    if s:
        S[name] = s
        print(f"{label:<16}{s['n']:>5}{s['mean']:>9}{s['sd']:>9}{s['cv']:>7}"
              f"{s['min']:>8}{s['p05']:>8}{s['med']:>8}{s['p95']:>8}{s['max']:>9}")

# ---- 异常值检测（MAD 法）----
print("\n" + "=" * 84)
print("异常值检测（中位数绝对偏差法，|z_MAD| > 3.5）")
print("=" * 84)
outliers = {}
for name in ["hrv_mean", "rhr", "sleep_hours", "steps", "active_energy", "workout_min"]:
    c = col(name)
    if len(c) < 30:
        continue
    vs = [v for _, v in c]
    med = st.median(vs)
    mad = st.median([abs(v - med) for v in vs]) or 1e-9
    bad = [(d, v) for d, v in c if abs(0.6745 * (v - med) / mad) > 3.5]
    outliers[name] = bad
    print(f"  {name:<14} 异常 {len(bad):>3} / {len(c)} 天", end="")
    if bad:
        ex = sorted(bad, key=lambda x: -abs(x[1] - med))[:4]
        print("  例：" + ", ".join(f"{d}={v:.0f}" for d, v in ex))
    else:
        print()

# ---- 缺失模式 ----
print("\n" + "=" * 84)
print("缺失模式")
print("=" * 84)
tot = len(rows)
for name, label in [("hrv_mean", "HRV"), ("rhr", "静息心率"), ("sleep_hours", "睡眠"),
                    ("wrist_temp", "腕温"), ("resp", "呼吸频率"), ("steps", "步数"),
                    ("active_energy", "活动能量")]:
    miss = sum(1 for r in rows if not r.get(name))
    print(f"  {label:<12} 缺失 {miss:>3} 天 ({miss/tot*100:>4.1f}%)")

# 连续缺失最长段
def longest_gap(name):
    miss = [r["date"] for r in rows if not r.get(name)]
    if not miss:
        return 0, None
    ds = sorted(date.fromisoformat(x) for x in miss)
    best = cur = 1
    start = bs = ds[0]
    for i in range(1, len(ds)):
        if (ds[i] - ds[i - 1]).days == 1:
            cur += 1
        else:
            if cur > best:
                best, bs = cur, start
            cur, start = 1, ds[i]
    if cur > best:
        best, bs = cur, start
    return best, bs.isoformat()


print("\n  最长连续缺失段：")
for name, label in [("hrv_mean", "HRV"), ("rhr", "静息心率"), ("sleep_hours", "睡眠"),
                    ("wrist_temp", "腕温")]:
    g, s = longest_gap(name)
    print(f"    {label:<10} {g} 天" + (f"（始于 {s}）" if s else ""))

# ---- 训练节律 ----
wk = [r for r in rows if r.get("workout_n") and int(r["workout_n"] or 0) > 0]
print(f"\n{'='*84}\n训练节律")
print(f"  有训练的天数：{len(wk)} / {tot} 天 ({len(wk)/tot*100:.0f}%)")
wd = Counter(date.fromisoformat(r["date"]).weekday() for r in wk)
names = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
print("  按星期分布：" + "  ".join(f"{names[i]}:{wd.get(i,0)}" for i in range(7)))

# 训练/非训练日的 HRV 对比
hv = {d: v for d, v in col("hrv_mean")}
tr = [hv[r["date"]] for r in wk if r["date"] in hv]
nt = [hv[r["date"]] for r in rows
      if not (r.get("workout_n") and int(r["workout_n"] or 0) > 0) and r["date"] in hv]
if tr and nt:
    print(f"\n  HRV 均值：训练日 {st.mean(tr):.1f} ms (n={len(tr)})  "
          f"非训练日 {st.mean(nt):.1f} ms (n={len(nt)})  差 {st.mean(tr)-st.mean(nt):+.1f} ms")

# 次日效应：训练日 → 次日 HRV
print("\n  训练日次日 HRV 变化（初步检验效应是否存在）：")
dmap = {r["date"]: r for r in rows}
dates = sorted(dmap)
pairs = []
for i in range(1, len(dates)):
    prev, cur = dmap[dates[i - 1]], dmap[dates[i]]
    if (date.fromisoformat(cur["date"]) - date.fromisoformat(prev["date"])).days != 1:
        continue
    try:
        h0 = float(prev["hrv_mean"]); h1 = float(cur["hrv_mean"])
    except (TypeError, ValueError):
        continue
    pairs.append((prev, cur, h1 - h0))
trp = [d for p, c, d in pairs if p.get("workout_n") and int(p["workout_n"] or 0) > 0]
ntp = [d for p, c, d in pairs if not (p.get("workout_n") and int(p["workout_n"] or 0) > 0)]
if trp and ntp:
    print(f"    训练后次日 ΔHRV = {st.mean(trp):+.2f} ms (n={len(trp)})")
    print(f"    非训练后次日 ΔHRV = {st.mean(ntp):+.2f} ms (n={len(ntp)})")

json.dump({"stats": S,
           "outliers": {k: len(v) for k, v in outliers.items()},
           "train_days": len(wk), "total_days": tot},
          open(HERE + "/qc_report.json", "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("\n质检完成 -> qc_report.json")
