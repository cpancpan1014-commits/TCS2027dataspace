# -*- coding: utf-8 -*-
"""重绘 Figure 2（森林图）：修正队列/受试者标签混用，并把 Cohort B 的
置信区间换成聚类稳健版本。按最终印刷宽度 3.40 in 出图，字号即印刷字号。
"""
import json, os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "figures")

rcParams["font.family"] = "DejaVu Sans"
rcParams["axes.linewidth"] = 0.6
rcParams["xtick.major.width"] = 0.5
rcParams["ytick.major.width"] = 0.5
rcParams["pdf.fonttype"] = 42
rcParams["ps.fonttype"] = 42

C_A = "#0072B2"
C_B = "#E69F00"
C_C = "#009E73"

W = 2.65

c2 = json.load(open(os.path.join(HERE, "compare_two.json"), encoding="utf-8"))
ls = json.load(open(os.path.join(HERE, "lifesnaps_result.json"), encoding="utf-8"))
bs = json.load(open(os.path.join(HERE, "cohortB_se.json"), encoding="utf-8"))

rows = []
e = c2["effects"]
for lab, key in (("Cohort A (P1): HRV", "P1_HRV"),
                 ("Cohort A (P1): resting HR", "P1_\u9759\u606f\u5fc3\u7387"),
                 ("Cohort A (P2): HRV", "P2_HRV"),
                 ("Cohort A (P2): resting HR", "P2_\u9759\u606f\u5fc3\u7387")):
    rows.append((lab, e[key]["beta_z"], e[key]["ci"][0], e[key]["ci"][1], "A"))

for lab, key in (("Cohort B: readiness \u2190 sRPE", "load"),
                 ("Cohort B: readiness \u2190 active min", "vam"),
                 ("Cohort B: readiness \u2190 moderate min", "mam")):
    d = bs[key]
    lo = d["beta"] - 1.96 * d["se_cluster"]
    hi = d["beta"] + 1.96 * d["se_cluster"]
    rows.append((lab, d["beta"], lo, hi, "B"))

lab_map = {"calories": "Cohort C: RMSSD \u2190 calories",
           "very_active_minutes": "Cohort C: RMSSD \u2190 active min",
           "moderately_active_minutes": "Cohort C: RMSSD \u2190 moderate min",
           "lightly_active_minutes": "Cohort C: RMSSD \u2190 light min",
           "steps": "Cohort C: RMSSD \u2190 steps"}
for r in ls["regression"]:
    k = r["key"]
    if k in lab_map:
        rows.append((lab_map[k], r["beta_load"],
                     r["beta_load"] - 1.96 * r["se_load"],
                     r["beta_load"] + 1.96 * r["se_load"], "C"))

rows.reverse()
color_of = {"A": C_A, "B": C_B, "C": C_C}

fig, ax = plt.subplots(figsize=(W, 2.55))
y = np.arange(len(rows))
for i, (_, b, lo, hi, co) in enumerate(rows):
    sig = not (lo < 0 < hi)
    ax.plot([lo, hi], [i, i], lw=1.0, color=color_of[co], solid_capstyle="butt")
    ax.plot(b, i, "s" if sig else "o", ms=3.8 if sig else 3.0,
            color=color_of[co], markeredgecolor="white", markeredgewidth=0.45)

ax.axvline(0, color="black", lw=0.7, ls=(0, (3, 3)))
ax.set_yticks(y)
ax.set_yticklabels([r[0] for r in rows], fontsize=5.8)
ax.set_xlabel("Standardised load effect (\u03b2, z units)", fontsize=6.4, labelpad=2)
ax.set_xlim(-0.46, 0.24)
ax.set_ylim(-0.7, len(rows) - 0.3)
ax.tick_params(axis="x", labelsize=6.0)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

handles = [plt.Line2D([], [], color=C_A, lw=1.8, label="Cohort A (1 cluster)"),
           plt.Line2D([], [], color=C_B, lw=1.8, label="Cohort B (9\u201311 clusters)"),
           plt.Line2D([], [], color=C_C, lw=1.8, label="Cohort C (36 clusters)"),
           plt.Line2D([], [], color="black", marker="s", ls="none", ms=3.8,
                      label="significant (\u25a0)")]
leg = fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, -0.005),
                 frameon=False, ncol=2, handlelength=1.3, columnspacing=1.0,
                 fontsize=5.4)
fig.subplots_adjust(bottom=0.255, left=0.40, right=0.985, top=0.985)

fig.savefig(os.path.join(OUT, "figure2_forest.png"), dpi=300, bbox_inches="tight")
fig.savefig(os.path.join(OUT, "figure2_forest.pdf"), bbox_inches="tight")
print("figure2_forest ok", [r[0] for r in rows])
