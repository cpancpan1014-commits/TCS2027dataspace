# -*- coding: utf-8 -*-
"""审稿意见触发的复算：统一口径 + 睡眠协变量敏感性 + 缺失样本量。

输出到 revision_checks.json，供正文引用。
"""
import csv, json, math, os, statistics as st, datetime as dt
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
PM = os.path.join(HERE, "pmdata")
LS = os.path.join(HERE, "lifesnaps", "rais_anonymized", "csv_rais_anonymized",
                  "daily_fitbit_sema_df_unprocessed.csv")

MIN_PAIRS = 20
UNIT_SCALE = {"sleep_duration": 1 / 3_600_000}
ZERO_AS_MISSING = {"rmssd", "nremhr", "full_sleep_breathing_rate"}


# ------------------------------------------------------------------ 线性代数
def solve(A, b):
    n = len(A)
    M = [A[i][:] + [b[i]] for i in range(n)]
    I = [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]
    for c in range(n):
        piv = max(range(c, n), key=lambda r: abs(M[r][c]))
        if abs(M[piv][c]) < 1e-12:
            return None, None
        M[c], M[piv] = M[piv], M[c]
        I[c], I[piv] = I[piv], I[c]
        pv = M[c][c]
        M[c] = [x / pv for x in M[c]]
        I[c] = [x / pv for x in I[c]]
        for r in range(n):
            if r != c:
                fac = M[r][c]
                if fac:
                    M[r] = [M[r][j] - fac * M[c][j] for j in range(n + 1)]
                    I[r] = [I[r][j] - fac * I[c][j] for j in range(n)]
    return [M[i][n] for i in range(n)], I


def cluster_ols(X, y, groups):
    """OLS + 按受试者聚类稳健 SE。X 不含截距。"""
    n, k = len(y), len(X[0])
    Xd = [row + [1.0] for row in X]
    kk = k + 1
    XtX = [[sum(Xd[i][a] * Xd[i][b] for i in range(n)) for b in range(kk)] for a in range(kk)]
    Xty = [sum(Xd[i][a] * y[i] for i in range(n)) for a in range(kk)]
    beta, inv = solve(XtX, Xty)
    if beta is None:
        return None
    res = [y[i] - sum(beta[a] * Xd[i][a] for a in range(kk)) for i in range(n)]
    meat = [[0.0] * kk for _ in range(kk)]
    gm = defaultdict(list)
    for i, g in enumerate(groups):
        gm[g].append(i)
    G = len(gm)
    for idx in gm.values():
        sg = [sum(Xd[i][a] * res[i] for i in idx) for a in range(kk)]
        for a in range(kk):
            for b in range(kk):
                meat[a][b] += sg[a] * sg[b]
    corr = (G / (G - 1.0)) * ((n - 1.0) / (n - kk)) if G > 1 and n > kk else 1.0
    V = [[sum(inv[a][c] * meat[c][d] * inv[b][d]
              for c in range(kk) for d in range(kk)) * corr
          for b in range(kk)] for a in range(kk)]
    coef = []
    for a in range(k):
        se = math.sqrt(max(V[a][a], 0.0))
        coef.append({"beta": beta[a], "se": se,
                     "t": beta[a] / se if se > 0 else 0.0})
    ym = st.mean(y)
    sst = sum((v - ym) ** 2 for v in y)
    sse = sum(e * e for e in res)
    return {"coef": coef, "n": n, "clusters": G,
            "r2": 1 - sse / sst if sst > 0 else 0.0}


def plain_ols(X, y):
    n, k = len(y), len(X[0])
    Xd = [row + [1.0] for row in X]
    kk = k + 1
    XtX = [[sum(Xd[i][a] * Xd[i][b] for i in range(n)) for b in range(kk)] for a in range(kk)]
    Xty = [sum(Xd[i][a] * y[i] for i in range(n)) for a in range(kk)]
    beta, inv = solve(XtX, Xty)
    if beta is None:
        return None
    res = [y[i] - sum(beta[a] * Xd[i][a] for a in range(kk)) for i in range(n)]
    s2 = sum(e * e for e in res) / (n - kk)
    coef = []
    for a in range(k):
        se = math.sqrt(max(s2 * inv[a][a], 0.0))
        coef.append({"beta": beta[a], "se": se, "t": beta[a] / se if se > 0 else 0.0})
    ym = st.mean(y)
    sst = sum((v - ym) ** 2 for v in y)
    sse = sum(e * e for e in res)
    return {"coef": coef, "n": n, "r2": 1 - sse / sst if sst > 0 else 0.0}


def zs(vs):
    m, s = st.mean(vs), st.pstdev(vs) or 1e-9
    return [(v - m) / s for v in vs]


def zmap(d):
    vs = list(d.values())
    m, s = st.mean(vs), st.pstdev(vs) or 1e-9
    return {k: (v - m) / s for k, v in d.items()}


def fnum(v):
    try:
        x = float(v)
        return x if x == x else None
    except Exception:
        return None


def gap(a, b):
    try:
        return (dt.date.fromisoformat(b) - dt.date.fromisoformat(a)).days
    except Exception:
        return 2


# ================================================================ Cohort B
def load_pmdata():
    import re
    subs = sorted(d for d in os.listdir(PM) if re.fullmatch(r"p\d\d", d))
    out = {}
    for p in subs:
        day = {}
        w = os.path.join(PM, p, "pmsys", "wellness.csv")
        if os.path.exists(w):
            for r in csv.DictReader(open(w, encoding="utf-8-sig")):
                d = (r.get("effective_time_frame") or "")[:10]
                if not d:
                    continue
                e = day.setdefault(d, {})
                for k in ("readiness", "fatigue", "mood", "sleep_quality", "soreness", "stress"):
                    v = fnum(r.get(k))
                    if v is not None:
                        e[k] = v
                v = fnum(r.get("sleep_duration_h"))
                if v is not None:
                    e["sleep_h"] = v
        s = os.path.join(PM, p, "pmsys", "srpe.csv")
        if os.path.exists(s):
            for r in csv.DictReader(open(s, encoding="utf-8-sig")):
                d = (r.get("end_date_time") or "")[:10]
                rpe, dur = fnum(r.get("perceived_exertion")), fnum(r.get("duration_min"))
                if not d or rpe is None or dur is None:
                    continue
                day.setdefault(d, {})
                day[d]["load"] = day[d].get("load", 0.0) + rpe * dur
        for fn, key in [("very_active_minutes.json", "vam"),
                        ("moderately_active_minutes.json", "mam")]:
            fp = os.path.join(PM, p, "fitbit", fn)
            if not os.path.exists(fp):
                continue
            for it in json.load(open(fp, encoding="utf-8")):
                d = (it.get("dateTime") or "")[:10]
                v = fnum(it.get("value"))
                if d and v is not None:
                    day.setdefault(d, {})[key] = v
        ss = os.path.join(PM, p, "fitbit", "sleep_score.csv")
        if os.path.exists(ss):
            for row in csv.DictReader(open(ss, encoding="utf-8-sig")):
                d = (row.get("timestamp") or row.get("date") or "")[:10]
                v = fnum(row.get("overall_score") or row.get("sleep_score"))
                if d and v is not None:
                    day.setdefault(d, {})["sleep_score"] = v
        out[p] = day
    return out


def cohort_b(data, load_key="load", sleep_key=None):
    """复刻 pmdata_analysis 第四节口径：该负荷有 ≥30 天的受试者，相邻日对。"""
    keep = []
    for p, dd in data.items():
        ntr = sum(1 for v in dd.values() if v.get("load", 0) > 0)
        if ntr >= 20:
            keep.append(p)
    rows = []
    for p in keep:
        dd = data[p]
        if sum(1 for v in dd.values() if load_key in v) < 30:
            continue
        ds = sorted(d for d in dd if "readiness" in dd[d])
        for i in range(1, len(ds)):
            d0, d1 = ds[i - 1], ds[i]
            if gap(d0, d1) != 1:
                continue
            if sleep_key and sleep_key not in dd[d0]:
                continue
            rows.append((p, dd[d0]["readiness"], dd[d0].get(load_key, 0.0),
                         dd[d1]["readiness"], dd[d0].get(sleep_key) if sleep_key else 0.0))
    # 原始值合并
    Xr = [[r[1], r[2]] for r in rows]
    yr = [r[3] for r in rows]
    if sleep_key:
        Xr = [[r[1], r[2], r[4]] for r in rows]
    mr = plain_ols(Xr, yr)
    # 个体内 z
    bysub = defaultdict(list)
    for r in rows:
        bysub[r[0]].append(r)
    X, y, g = [], [], []
    for p, rs in bysub.items():
        if len(rs) < 10:
            continue
        a_, b_ = zs([r[1] for r in rs]), zs([r[2] for r in rs])
        c_ = zs([r[3] for r in rs])
        if sleep_key:
            e_ = zs([r[4] for r in rs])
            for i in range(len(rs)):
                X.append([a_[i], b_[i], e_[i]]); y.append(c_[i]); g.append(p)
        else:
            for i in range(len(rs)):
                X.append([a_[i], b_[i]]); y.append(c_[i]); g.append(p)
    mz = cluster_ols(X, y, g)
    return {"raw": mr, "z": mz, "n_rows": len(rows)}


# ================================================================ Cohort C
def load_lifesnaps():
    per = defaultdict(lambda: defaultdict(dict))
    for r in csv.DictReader(open(LS, encoding="utf-8")):
        uid, d = r.get("id"), r.get("date")
        if not uid or not d:
            continue
        dd = per[uid][d[:10]]
        for c, v in r.items():
            if c in ("id", "date", ""):
                continue
            x = fnum(v)
            if x is None:
                continue
            if c in ZERO_AS_MISSING and x == 0.0:
                continue
            if c in UNIT_SCALE:
                x *= UNIT_SCALE[c]
            dd[c] = x
    return per


def cohort_c(per, load_key, target="rmssd", with_sleep=False, min_days=MIN_PAIRS):
    X, y, g = [], [], []
    nsubj = 0
    for uid, days in per.items():
        ds = sorted(days)
        tgt = {d: days[d][target] for d in ds if target in days[d]}
        if len(tgt) < min_days + 1:
            continue
        Zt = zmap(tgt)
        Zl = zmap({d: days[d].get(load_key, 0.0) for d in ds})
        Zs = None
        if with_sleep:
            sl = {d: days[d]["sleep_duration"] for d in ds if "sleep_duration" in days[d]}
            if len(sl) < min_days:
                continue
            Zs = zmap(sl)
        pairs = [(ds[i - 1], ds[i]) for i in range(1, len(ds)) if gap(ds[i - 1], ds[i]) == 1]
        local = []
        for d0, d1 in pairs:
            if d0 not in Zt or d1 not in Zt or d0 not in Zl:
                continue
            if with_sleep and d0 not in Zs:
                continue
            row = [Zt[d0], Zl[d0]]
            if with_sleep:
                row.append(Zs[d0])
            local.append((row, Zt[d1]))
        if len(local) < min_days:
            continue
        nsubj += 1
        for row, c in local:
            X.append(row); y.append(c); g.append(uid)
    if len(y) < 100:
        return None
    m = cluster_ols(X, y, g)
    return m


# ================================================================ main
if __name__ == "__main__":
    res = {}

    print("=" * 76)
    print("一、Cohort B：sRPE 口径统一（同一 908 日对子集）")
    print("=" * 76)
    B = load_pmdata()
    bz = cohort_b(B, "load")
    r, z = bz["raw"], bz["z"]
    print(f"  合并原始值（不标准化）  n={r['n']}  R²={r['r2']:.3f}")
    print(f"    当日 readiness β={r['coef'][0]['beta']:+.3f} t={r['coef'][0]['t']:+.2f}")
    print(f"    负荷            β={r['coef'][1]['beta']:+.5f} t={r['coef'][1]['t']:+.2f}")
    print(f"  个体内 z + 聚类稳健 SE  n={z['n']} ({z['clusters']} clusters)  R²={z['r2']:.3f}")
    print(f"    当日 readiness β={z['coef'][0]['beta']:+.3f} t={z['coef'][0]['t']:+.2f}")
    print(f"    负荷            β={z['coef'][1]['beta']:+.4f} t={z['coef'][1]['t']:+.2f}")
    res["B_srpe"] = {"raw": {"n": r["n"], "r2": round(r["r2"], 4),
                             "load_beta": round(r["coef"][1]["beta"], 4),
                             "load_t": round(r["coef"][1]["t"], 2)},
                     "z": {"n": z["n"], "clusters": z["clusters"], "r2": round(z["r2"], 4),
                           "load_beta": round(z["coef"][1]["beta"], 4),
                           "load_t": round(z["coef"][1]["t"], 2),
                           "load_se": round(z["coef"][1]["se"], 4)}}

    print("\n" + "=" * 76)
    print("二、Cohort B：加入睡眠协变量（fitbit sleep score，当日）")
    print("=" * 76)
    bs = cohort_b(B, "load", sleep_key="sleep_score")
    if bs["z"]:
        zs_ = bs["z"]
        print(f"  个体内 z  n={zs_['n']} ({zs_['clusters']} clusters)  R²={zs_['r2']:.3f}")
        print(f"    负荷 β={zs_['coef'][1]['beta']:+.4f} t={zs_['coef'][1]['t']:+.2f}")
        print(f"    睡眠 β={zs_['coef'][2]['beta']:+.4f} t={zs_['coef'][2]['t']:+.2f}")
        res["B_srpe_sleep"] = {"n": zs_["n"], "clusters": zs_["clusters"],
                               "r2": round(zs_["r2"], 4),
                               "load_beta": round(zs_["coef"][1]["beta"], 4),
                               "load_t": round(zs_["coef"][1]["t"], 2),
                               "sleep_beta": round(zs_["coef"][2]["beta"], 4),
                               "sleep_t": round(zs_["coef"][2]["t"], 2)}
    else:
        print("  样本不足")
    # 另一种睡眠口径：wellness sleep_duration_h
    bs2 = cohort_b(B, "load", sleep_key="sleep_h")
    if bs2["z"]:
        z2 = bs2["z"]
        print(f"  [wellness sleep_duration_h] n={z2['n']} 负荷 β={z2['coef'][1]['beta']:+.4f} "
              f"t={z2['coef'][1]['t']:+.2f}")
        res["B_srpe_sleep_h"] = {"n": z2["n"], "load_beta": round(z2["coef"][1]["beta"], 4),
                                 "load_t": round(z2["coef"][1]["t"], 2)}

    print("\n" + "=" * 76)
    print("三、Cohort C：加入睡眠协变量（sleep_duration）")
    print("=" * 76)
    per = load_lifesnaps()
    cc = {}
    for key in ("calories", "steps", "very_active_minutes", "moderately_active_minutes",
                "lightly_active_minutes"):
        a = cohort_c(per, key, with_sleep=False)
        b = cohort_c(per, key, with_sleep=True)
        if not a or not b:
            continue
        cc[key] = {"no_sleep": {"n": a["n"], "clusters": a["clusters"],
                                "beta": round(a["coef"][1]["beta"], 4),
                                "t": round(a["coef"][1]["t"], 2)},
                   "with_sleep": {"n": b["n"], "clusters": b["clusters"],
                                  "beta": round(b["coef"][1]["beta"], 4),
                                  "t": round(b["coef"][1]["t"], 2),
                                  "sleep_beta": round(b["coef"][2]["beta"], 4),
                                  "sleep_t": round(b["coef"][2]["t"], 2)}}
        print(f"  {key:<28} 无睡眠 n={a['n']:>5} ({a['clusters']}人) "
              f"β={a['coef'][1]['beta']:+.4f} t={a['coef'][1]['t']:+.2f}"
              f"  | 含睡眠 n={b['n']:>5} ({b['clusters']}人) "
              f"β={b['coef'][1]['beta']:+.4f} t={b['coef'][1]['t']:+.2f}"
              f"  睡眠 t={b['coef'][2]['t']:+.2f}")
    res["C_with_sleep"] = cc

    json.dump(res, open(os.path.join(HERE, "revision_checks.json"), "w"),
              ensure_ascii=False, indent=1)
    print("\n已保存 revision_checks.json")
