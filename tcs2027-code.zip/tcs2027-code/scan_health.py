#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Apple Health export.xml 流式扫描（2.9GB，禁止整体载入内存）
一次遍历：统计全部指标类型 + 聚合 2026 年数据
"""
import csv, json, time, os
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))

SRC = "/Users/user/Downloads/apple_health_export/导出.xml"
OUT = HERE + "/health_data"
os.makedirs(OUT, exist_ok=True)
YEAR = "2026"

# 需要落盘的明细指标（低采样率）
SAVE_DETAIL = {
    "HKQuantityTypeIdentifierHeartRateVariabilitySDNN",
    "HKQuantityTypeIdentifierRestingHeartRate",
    "HKQuantityTypeIdentifierVO2Max",
    "HKQuantityTypeIdentifierAppleSleepingWristTemperature",
    "HKQuantityTypeIdentifierHeartRateRecoveryOneMinute",
    "HKQuantityTypeIdentifierWalkingHeartRateAverage",
    "HKQuantityTypeIdentifierRespiratoryRate",
    "HKQuantityTypeIdentifierBodyMass",
    "HKCategoryTypeIdentifierSleepAnalysis",
    "HKCategoryTypeIdentifierAppleStandHour",
    "HKCategoryTypeIdentifierMindfulSession",
}
# 需要按日聚合的高采样率指标
AGG_DAILY = {
    "HKQuantityTypeIdentifierHeartRate": ("hr", "mean"),
    "HKQuantityTypeIdentifierActiveEnergyBurned": ("active_energy", "sum"),
    "HKQuantityTypeIdentifierBasalEnergyBurned": ("basal_energy", "sum"),
    "HKQuantityTypeIdentifierStepCount": ("steps", "sum"),
    "HKQuantityTypeIdentifierDistanceWalkingRunning": ("distance", "sum"),
    "HKQuantityTypeIdentifierFlightsClimbed": ("flights", "sum"),
    "HKQuantityTypeIdentifierAppleExerciseTime": ("exercise_min", "sum"),
}

type_all = Counter()          # 全部年份：type -> count
type_2026 = Counter()         # 2026 年
range_2026 = {}               # type -> [min_date, max_date]
detail = defaultdict(list)    # type -> [(date, value, extra)]
agg = defaultdict(lambda: defaultdict(lambda: [0.0, 0]))  # (type,date) -> [sum,count]
agg_max = defaultdict(dict)   # 心率峰值
workouts = []
activity = {}

t0 = time.time()
n_lines = 0
n_records = 0


def attr(line, key):
    """从一行中提取属性值，找不到返回 ''"""
    k = f'{key}="'
    i = line.find(k)
    if i < 0:
        return ""
    i += len(k)
    j = line.find('"', i)
    return line[i:j] if j > 0 else ""


with open(SRC, "r", encoding="utf-8", errors="replace") as f:
    for line in f:
        n_lines += 1
        if n_lines % 2_000_000 == 0:
            print(f"  扫描 {n_lines/1e6:.1f}M 行... {time.time()-t0:.0f}s", flush=True)

        if not line.startswith(" <"):
            continue
        tag = line[2:line.find(" ", 2)] if " " in line[2:12] else line[2:].rstrip(">")
        if not (tag in ("Record", "Workout", "ActivitySummary")):
            continue

        # ---- Record ----
        if tag == "Record":
            i = line.find('type="')
            if i < 0:
                continue
            i += 6
            ty = line[i:line.find('"', i)]
            type_all[ty] += 1
            n_records += 1

            j = line.find('startDate="')
            if j < 0:
                continue
            d = line[j + 11: j + 21]   # YYYY-MM-DD

            if not d.startswith(YEAR):
                continue
            type_2026[ty] += 1
            lo, hi = range_2026.get(ty, (d, d))
            range_2026[ty] = (min(lo, d), max(hi, d))

            if ty in SAVE_DETAIL:
                detail[ty].append((d, attr(line, "value"), attr(line, "startDate"),
                                   attr(line, "endDate"), attr(line, "unit"),
                                   attr(line, "sourceName")))
            elif ty in AGG_DAILY:
                v = attr(line, "value")
                try:
                    fv = float(v)
                except (TypeError, ValueError):
                    continue
                name, how = AGG_DAILY[ty]
                s = agg[name][d]
                s[0] += fv
                s[1] += 1
                if name == "hr":
                    m = agg_max["hr_max"].get(d)
                    if m is None or fv > m:
                        agg_max["hr_max"][d] = fv

        # ---- Workout ----
        elif tag == "Workout":
            d = attr(line, "startDate")[:10]
            if not d.startswith(YEAR):
                continue
            type_2026["__Workout"] += 1
            w = {
                "date": d,
                "start": attr(line, "startDate"),
                "end": attr(line, "endDate"),
                "type": attr(line, "workoutActivityType"),
                "duration": attr(line, "duration"),
                "durationUnit": attr(line, "durationUnit"),
                "totalDistance": attr(line, "totalDistance"),
                "totalDistanceUnit": attr(line, "totalDistanceUnit"),
                "totalEnergy": attr(line, "totalEnergy"),
                "totalEnergyUnit": attr(line, "totalEnergyUnit"),
                "sourceName": attr(line, "sourceName"),
            }
            workouts.append(w)
            lo, hi = range_2026.get("__Workout", (d, d))
            range_2026["__Workout"] = (min(lo, d), max(hi, d))

        # ---- ActivitySummary ----
        elif tag == "ActivitySummary":
            dc = attr(line, "dateComponents")
            if not dc.startswith(YEAR):
                continue
            type_2026["__ActivitySummary"] += 1
            activity[dc] = {
                "activeEnergy": attr(line, "activeEnergyBurned"),
                "exercise": attr(line, "appleExerciseTime"),
                "stand": attr(line, "appleStandHours"),
                "moveGoal": attr(line, "activeEnergyBurnedGoal"),
                "exerciseGoal": attr(line, "appleExerciseTimeGoal"),
                "standGoal": attr(line, "appleStandHoursGoal"),
            }

elapsed = time.time() - t0
print(f"\n扫描完成：{n_lines} 行 / {n_records} 条 Record，用时 {elapsed:.0f}s")

# ---------- 落盘 ----------
json.dump({"type_all": dict(type_all.most_common()),
           "type_2026": dict(type_2026.most_common()),
           "range_2026": {k: list(v) for k, v in range_2026.items()},
           "lines": n_lines, "records": n_records, "elapsed_s": round(elapsed)},
          open(f"{OUT}/scan_summary.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

for ty, rows in detail.items():
    short = ty.replace("HKQuantityTypeIdentifier", "").replace("HKCategoryTypeIdentifier", "")
    with open(f"{OUT}/{short}.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["date", "value", "startDate", "endDate", "unit", "source"])
        w.writerows(rows)
    print(f"  {short}: {len(rows)} 条")

with open(f"{OUT}/daily_agg.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["date", "hr_mean", "hr_n", "hr_max", "active_energy", "basal_energy",
                "steps", "distance", "flights", "exercise_min"])
    for d in sorted(set(list(agg["hr"].keys()) + list(agg["steps"].keys()) + list(agg["active_energy"].keys()))):
        def g(name):
            s = agg[name].get(d)
            return (round(s[0], 2), s[1]) if s else ("", "")
        hs, hn = g("hr"); ae, aen = g("active_energy"); be, ben = g("basal_energy")
        st, stn = g("steps"); di, din = g("distance"); fl, fln = g("flights"); ex, exn = g("exercise_min")
        w.writerow([d,
                    round(hs / hn, 2) if hn else "", hn, agg_max["hr_max"].get(d, ""),
                    round(ae, 2) if aen else "", round(be, 2) if ben else "",
                    int(st) if stn else "", round(di, 2) if din else "",
                    int(fl) if fln else "", int(ex) if exn else ""])

with open(f"{OUT}/workouts.csv", "w", encoding="utf-8-sig", newline="") as f:
    if workouts:
        w = csv.DictWriter(f, fieldnames=list(workouts[0].keys()))
        w.writeheader()
        w.writerows(sorted(workouts, key=lambda x: x["start"]))

with open(f"{OUT}/activity_rings.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["date", "activeEnergy", "exerciseMin", "standHours",
                "moveGoal", "exerciseGoal", "standGoal"])
    for d in sorted(activity):
        a = activity[d]
        w.writerow([d, a["activeEnergy"], a["exercise"], a["stand"],
                    a["moveGoal"], a["exerciseGoal"], a["standGoal"]])

print(f"\n2026 年 Workout {len(workouts)} 次 / ActivitySummary {len(activity)} 天")
print("输出目录:", OUT)
