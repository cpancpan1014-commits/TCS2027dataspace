#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""逐条核实 references.bib 的 DOI 与元数据（Crossref）。"""
import os
import io, json, re, sys, time, urllib.parse, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))

BIB = "paper/references.bib"


def parse_bib(path):
    s = io.open(path, encoding="utf-8").read()
    out = []
    for m in re.finditer(r"@(\w+)\{([^,]+),(.*?)\n\}", s, re.S):
        typ, key, body = m.group(1), m.group(2).strip(), m.group(3)
        f = {}
        for fm in re.finditer(r"(\w+)\s*=\s*\{(.*?)\}\s*,?\s*(?=\n\s*\w+\s*=|\Z)", body, re.S):
            f[fm.group(1).lower()] = re.sub(r"\s+", " ", fm.group(2)).strip()
        out.append((typ, key, f))
    return out


def get(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": "ref-check/1.0 (mailto:pancheng1@gdust.edu.cn)"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def crossref_doi(doi):
    try:
        return get("https://api.crossref.org/works/" + urllib.parse.quote(doi))["message"]
    except Exception as e:
        return {"__err": str(e)}


def crossref_title(title):
    q = urllib.parse.quote(title)
    try:
        items = get("https://api.crossref.org/works?query.bibliographic=%s&rows=3" % q)["message"]["items"]
    except Exception as e:
        return None, str(e)
    return items, None


def norm(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def main():
    items = parse_bib(BIB)
    print("total entries:", len(items), "\n")
    rep = []
    for typ, key, f in items:
        doi = f.get("doi", "")
        title = f.get("title", "")
        year = f.get("year", "")
        status, got = "", {}
        if doi:
            m = crossref_doi(doi)
            if "__err" in m:
                status = "DOI_FAIL"
            else:
                got = {
                    "title": (m.get("title") or [""])[0],
                    "year": str((m.get("issued", {}).get("date-parts") or [[None]])[0][0]),
                    "journal": (m.get("container-title") or [""])[0],
                    "vol": m.get("volume", ""),
                    "page": m.get("page") or m.get("article-number", ""),
                }
                t_ok = norm(title)[:40] in norm(got["title"]) or norm(got["title"])[:40] in norm(title)
                status = "OK" if t_ok else "TITLE_MISMATCH"
        else:
            status = "NO_DOI"
        # 无 DOI 或失败 -> 标题检索
        alt = []
        if status != "OK":
            hits, err = crossref_title(title)
            if hits:
                for h in hits:
                    alt.append({
                        "title": (h.get("title") or [""])[0][:95],
                        "year": str((h.get("issued", {}).get("date-parts") or [[None]])[0][0]),
                        "doi": h.get("DOI", ""),
                        "journal": (h.get("container-title") or [""])[0][:45],
                    })
            elif err:
                alt = [{"err": err}]
        rep.append({"key": key, "doi": doi, "year": year, "title": title[:80],
                    "status": status, "got": got, "alt": alt})
        print(f"[{status:14s}] {key:20s} {year:5s} {title[:62]}")
        if status != "OK":
            for a in alt:
                print("      -> ", a)
            if got:
                print("      doi->", got)
        time.sleep(0.25)
    io.open("ref_verify.json", "w", encoding="utf-8").write(json.dumps(rep, ensure_ascii=False, indent=1))
    print("\nsaved ref_verify.json")


if __name__ == "__main__":
    main()
